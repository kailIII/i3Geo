<?php
/*
Title: classe_shp.php

Manipula��o de shapefile.

Licenca:

GPL2


I3Geo Interface Integrada de Ferramentas de Geoprocessamento para Internet

Direitos Autorais Reservados (c) 2006 Minist�rio do Meio Ambiente Brasil
Desenvolvedor: Edmar Moretti edmar.moretti@mma.gov.br

Este programa � software livre; voc� pode redistribu�-lo
e/ou modific�-lo sob os termos da Licen�a P�blica Geral
GNU conforme publicada pela Free Software Foundation;

Este programa � distribu�do na expectativa de que seja �til,
por�m, SEM NENHUMA GARANTIA; nem mesmo a garantia impl�cita
de COMERCIABILIDADE OU ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
Consulte a Licen�a P�blica Geral do GNU para mais detalhes.
Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral do
GNU junto com este programa; se n�o, escreva para a
Free Software Foundation, Inc., no endere�o
59 Temple Street, Suite 330, Boston, MA 02111-1307 USA.

Arquivo:

i3geo/classesphp/classe_shp.php
*/
/*
Classe: SHP
*/
class SHP
{
	/*
	Variavel: $mapa
	
	Objeto mapa
	*/
	public $mapa;
	/*
	Variavel: $arquivo
	
	Arquivo map file
	*/
	protected $arquivo;
	/*
	Variavel: $layer
	
	Objeto layer
	*/
	protected $layer;
	/*
	Variavel: $nome
	
	Nome do layer
	*/
	protected $nome;
	/*
	Variavel: $dbaseExiste
	
	Indica se a biblioteca dbase est� carregada
	*/
	protected $dbaseExiste;
	
/*
function: __construct

Cria um objeto map e seta a variavel tema 

parameters:

$map_file - Endere�o do mapfile no servidor.

$tema - nome do tema

$ext - extensao geogr�fica que ser� aplicada ao mapa
*/
	function __construct($map_file,$tema="",$locaplic="",$ext="")
	{
		//error_reporting(E_ALL);
		$this->dbaseExiste = false;
		if(function_exists("dbase_create"))
		{$this->dbaseExiste = true;}
		
  		$this->locaplic = $locaplic;
  		$this->mapa = ms_newMapObj($map_file);
  		$this->arquivo = $map_file;
  		$this->tema = $tema;
  		if($tema != "" && @$this->mapa->getlayerbyname($tema))
  		{
  			$this->layer = $this->mapa->getlayerbyname($tema);
  		}
  		$this->nome = $tema;
		if($ext && $ext != ""){
			$e = explode(" ",$ext);
			$extatual = $this->mapa->extent;
			$extatual->setextent((min($e[0],$e[2])),(min($e[1],$e[3])),(max($e[0],$e[2])),(max($e[1],$e[3])));
		}		
	}
/*
function: salva

Salva o mapfile atual 
*/	
 	function salva()
 	{
	  	if (connection_aborted()){exit();}
	  	$this->mapa->save($this->arquivo);
	}
/*
function: criaSHPvazio

Cria um shape file do tipo pontual vazio no diret�rio local

Parameter:

$tituloTema - t�tulo do novo tema

return:
Nome do tema criado.
*/
	function criaSHPvazio($tituloTema="")
	{
		$diretorio = dirname($this->arquivo);
		$novonomelayer = nomeRandomico();
		$nomeshp = $diretorio."/".$novonomelayer;
		$def[] = array("ID","C","50");
		if($this->dbaseExiste == false){
			if(file_exists($this->locaplic."/pacotes/phpxbase/api_conversion.php"))
			{include_once($this->locaplic."/pacotes/phpxbase/api_conversion.php");}
			else	
			{include_once "../pacotes/phpxbase/api_conversion.php";}
			$db = xbase_create($nomeshp.".dbf", $def);
			xbase_close($db);
		}
		else
		{
			$db = dbase_create($nomeshp.".dbf", $def);
			dbase_close($db);
		}
		$tipol = MS_SHP_POINT;
		$l = criaLayer($this->mapa,MS_LAYER_POINT,MS_DEFAULT,"Ins","SIM");
		$novoshpf = ms_newShapefileObj($nomeshp, $tipol);
		$novoshpf->free();
		$novoshpf = ms_newShapefileObj($nomeshp.".shp", -2);
		$novoshpf->free();
		if($tituloTema == "")
		{$tituloTema = $novonomelayer." pontos";}
		$l->setmetadata("tema",$tituloTema);
		$l->setmetadata("TEMALOCAL","SIM");
		$l->setmetadata("DOWNLOAD","sim");
		$l->set("data",$nomeshp);
		$l->set("name",$novonomelayer);
		$classe = $l->getclass(0);
		$estilo = $classe->getstyle(0);
		$estilo->set("symbolname","ponto");
		$estilo->set("size",6);
		$cor = $estilo->color;
		$cor->setrgb(255,210,0);
		$cor = $estilo->outlinecolor;
		$cor->setrgb(255,0,0);
		return($novonomelayer);
	}
/*
function: insereSHP

Insere um ponto em um shape file no diret�rio local

parameters:
$xy - X e y do novo ponto, separados por espa�os. Pode ser mais de um ponto.

$projecao - c�digo epsg da proje��o das coordenadas
*/
	function insereSHP($xy,$projecao,$item="",$valor="")
	{
		if(!$this->layer){return "erro";}
		if($this->dbaseExiste == false){
			if(file_exists($this->locaplic."/pacotes/phpxbase/api_conversion.php"))
			include_once($this->locaplic."/pacotes/phpxbase/api_conversion.php");
			else	
			include_once "../pacotes/phpxbase/api_conversion.php";
		}
		$xy = explode(" ",$xy);
		$data = $this->layer->data;
		$data = explode(".shp",$data);
		$data = $data[0];
		$items = pegaItens($this->layer);
		$dbname = $data.".dbf";
		
		if($this->dbaseExiste == false)
		$db=xbase_open($dbname,2);
		else
		$db=dbase_open($dbname,2);
		
		for($i=0;$i<(count($xy) / 2);++$i)
		{
			$reg = array();
			foreach ($items as $ni)
			{
				//verifica se deve acrescentar o valor para um item, caso tenha sido definido
				if($ni == $item)
				$reg[] = $valor;
				else
				$reg[] = "-";
			}
			if($this->dbaseExiste == false)
			xbase_add_record($db,$reg);
			else
			dbase_add_record($db,$reg);
		}
		if($this->dbaseExiste == false)
		xbase_close($db);
		else
		dbase_close($db);
		if (@$shapefileObj = ms_newShapefileObj($data,-2))
		{
			for($i=0;$i<(count($xy));$i=$i+2)
			{
				$poPoint = ms_newpointobj();
				$poPoint->setXY($xy[$i],$xy[$i+1]);
				if($projecao != "")
				{
					$projOutObj = ms_newprojectionobj("proj=latlong");
					$projInObj = ms_newprojectionobj("init=epsg:".$projecao);
					$poPoint->project($projInObj, $projOutObj);
				}
				$shapefileObj->addpoint($poPoint);
			}
			$shapefileObj->free();
			return("ok");
		}
		else
		{return("erro");}
	}
/*
function: insereSHPgrafico

Insere um ponto em um shape file, criado no diret�rio tempor�rio, e adiciona ao mapa
atual. O layer adicionado � representado como um s�mbolo, constru�do a partir de uma
imagem tempor�ria representando o gr�fico criado.

parameters:

$x - Coordenada x.

$y - Coordenada Y.

$itens - Lista de itens

$imgurl - Endere�o da imagem atual

$width - Largura do gr�fico

$inclinacao - Inclina��o do gr�fico

$shadow_height - Tamanho da sombra do gr�fico

Include:
<classe_atributos.php>, <graficopizza.php>
*/
	function insereSHPgrafico($x,$y,$itens,$width,$inclinacao,$shadow_height)
	{
		if(!isset($tipo)){$tipo = "pizza";}
		//nome do novo tema
		$temaedit = nomeRandomico();
		//pega os valores
		include_once($this->locaplic."/classesphp/classe_atributos.php");
		$m = new Atributos($this->arquivo,$this->tema);
		$shape = $m->identificaQBP($this->nome,$x,$y,$this->arquivo,0,"","shape");
		if ((is_array($shape)) && ($shape[0] == " "))
		{
			return("erro.Nenhum valor encontrado");
		}
		else
		{
			$itens = explode("*",$itens);
			foreach ($itens as $i)
			{
				$ii = explode(",",$i);
				$v = $shape->values[$ii[0]];
				if (!is_numeric($v))
				{return("erro. Dados nao numericos.");}
				$valor[] = $v;
				$cor[] = $ii[1].",".$ii[2].",".$ii[3];
			}
			$data = implode("*",$valor);
			$cores = implode("*",$cor);
			if ($tipo == "pizza")
			{
				//gera a figura
				include_once($this->locaplic."/classesphp/graficopizza.php");
				$res = graficopizza($data,$width,$inclinacao,$shadow_height,$cores,$this->arquivo,$temaedit);
				$img = explode(",",$res);
			}
			//insere simbolo
			$nomes = nomeRandomico();
			$nId = ms_newsymbolobj($this->mapa, "foto");
			$oSymbol = $this->mapa->getsymbolobjectbyid($nId);
			$oSymbol->set("inmapfile", MS_TRUE);
			$oSymbol->set("type",MS_SYMBOL_PIXMAP);
			$oSymbol->setimagepath($img[0]);
			$oSymbol->set("name",$nomes);
			$pinlayer = criaLayer($this->mapa,MS_LAYER_POINT,MS_DEFAULT,"Gr�fico (".$temaedit.")","SIM");
			$c = $pinlayer->getclass(0);
			$e = $c->getstyle(0);
			$pinlayer->set("name",$temaedit);
			$c->set("name","");
			if(!isset($tamanho)){$tamanho = 50;}
			$e->set("size",$tamanho);
			$e->set("symbolname",$nomes);
			$pinlayer->set("opacity",MS_GD_ALPHA);
			$shp = ms_newshapeobj(MS_SHAPE_POINT);
			$lin = ms_newlineobj();
			$lin->addxy($x,$y);
			$shp->add($lin);
			$pinlayer->addfeature($shp);
			$this->salva();
			return("ok");
		}
	}
/*
function: listaPontosShape

Lista as coordenadas dos pontos de um layer

Funciona apenas com elementos do tipo ponto

return:

array - xy
*/
	function listaPontosShape()
	{
		if(!$this->layer){return "erro";}		
		$sopen = $this->layer->open();
		if($sopen == MS_FAILURE){return "erro";}
		$prjMapa = $this->mapa->getProjection();
		$prjTema = $this->layer->getProjection();
		$ret = $this->mapa->extent;
		if (($prjTema != "") && ($prjMapa != $prjTema))
		{
			$projOutObj = ms_newprojectionobj($prjTema);
			$projInObj = ms_newprojectionobj($prjMapa);
			$ret->project($projInObj, $projOutObj);
		}
		$this->layer->whichShapes($ret);
		$xy = array();
		while ($shape = $this->layer->nextShape())
		{
			$lin = $shape->line(0);
			$pt = $lin->point(0);
			$xy[] = array("x"=>$pt->x,"y"=>$pt->y);
		}
		$this->layer->close();
		return $xy;
	}
/*
function: listaPontosShapeSel

Lista as coordenadas dos elementos selecionados de um layer

Funciona com elementos pontuais ou lineares

return:

array - xy
*/
	function listaPontosShapeSel()
	{
		//error_reporting(E_ALL);
		if(!$this->layer){return "erro";}
		$this->layer->set("template","none.htm");
		$this->layer->setfilter("");
		$existesel = carregaquery($this->arquivo,&$this->layer,&$this->mapa);
		$sopen = $this->layer->open();
		if($sopen == MS_FAILURE){return "erro";}
		$res_count = $this->layer->getNumresults();
		$xy = array();
		for ($i = 0; $i < $res_count; ++$i)
		{
			$result = $this->layer->getResult($i);
			$shp_index  = $result->shapeindex;
			$shape = $this->layer->getfeature($shp_index,-1);
			$nlinhas = $shape->numlines;
			for($j = 0;$j < $nlinhas; ++$j){
				$lin = $shape->line($j);
				$npontos = $lin->numpoints;
				for($k = 0;$k < $npontos; ++$k){
					$pt = $lin->point($k);
					$xy[] = array("x"=>$pt->x,"y"=>$pt->y);
				}
			}
		}
		$fechou = $this->layer->close();
		return $xy;
	}	
/*
function: ultimoXY

Obt�m as coordenadas xy do �ltimo ponto existente no layer. O �ltimo ponto � considerado entre aqueles que est�o vis�veis no mapa atual

return:
array("layerprj"=>$xylayer,"mapprj"=>$xymapa)
*/
	function ultimoXY()
	{
		if(!$this->layer){return "erro";}
		$this->layer->queryByrect($this->mapa->extent);
		$res_count = $this->layer->getNumresults();
		$sopen = $this->layer->open();
		if($sopen == MS_FAILURE){return "erro";}
		$xy = array();

		$result = $this->layer->getResult($res_count - 1);
		$shp_index  = $result->shapeindex;
		$shape = $this->layer->getfeature($shp_index,-1);
		$lin = $shape->line(0);
		$pt = $lin->point(0);
		$this->layer->close();
		$xylayer = array("x"=>$pt->x,"y"=>$pt->y);
		$prjMapa = $this->mapa->getProjection();
		$prjTema = $this->layer->getProjection();
		if (($prjTema != "") && ($prjMapa != $prjTema))
		{
			$projInObj = ms_newprojectionobj($prjTema);
			$projOutObj = ms_newprojectionobj($prjMapa);
			$pt->project($projInObj, $projOutObj);
			$xymapa = array("x"=>$pt->x,"y"=>$pt->y);
		}
		else
		{$xymapa = $xylayer;}	
		return array("layerprj"=>$xylayer,"mapprj"=>$xymapa);
	}

/*
function: shpPT2shp

Cria um tema linear ou poligonal com base em pontos de um tema pontual.

parameters:
$locaplic - Localiza��o do I3geo

$para - linha|poligono
*/
	function shpPT2shp($locaplic,$para)
	{
		if(!$this->layer){return "erro";}
		$this->layer->set("template","none.htm");
		$diretorio = dirname($this->arquivo);
		$tipol = MS_SHP_ARC;
		$tipos = MS_SHAPE_LINE;
		if ($para == "poligono")
		{
	 		$tipol = MS_SHP_POLYGON;
	 		$tipos = MS_SHAPE_POLYGON;
		}
		$novonomelayer = nomeRandomico();
		$nomeshp = $diretorio."/".$novonomelayer;
		$items = pegaItens($this->layer);
		// cria o dbf
		$def = array();
		foreach ($items as $ni)
		{
			$temp = strtoupper($ni);
			$def[] = array($temp,"C","254");
		}
		//para manipular dbf
		if($this->dbaseExiste == false)
		{
			if(file_exists($this->locaplic."/pacotes/phpxbase/api_conversion.php"))
			{include_once($this->locaplic."/pacotes/phpxbase/api_conversion.php");}
			else	
			{include_once "../pacotes/phpxbase/api_conversion.php";}
			$db = xbase_create($nomeshp.".dbf", $def);
		}
		else
		{$db = dbase_create($nomeshp.".dbf", $def);}
		$dbname = $nomeshp.".dbf";
		$reg = array();
		$novoshpf = ms_newShapefileObj($nomeshp.".shp", $tipol);
		$this->layer->open();
		
		$prjMapa = $this->mapa->getProjection();
		$prjTema = $this->layer->getProjection();
		
		$ret = $this->mapa->extent;
		if (($prjTema != "") && ($prjMapa != $prjTema))
		{
			$projOutObj = ms_newprojectionobj($prjTema);
			$projInObj = ms_newprojectionobj($prjMapa);
			$ret->project($projInObj, $projOutObj);
		}
		$this->layer->whichShapes($ret);
		$linha = ms_newLineObj();
		$pponto = "";
		$pontos = array();
		while ($shape = $this->layer->nextShape())
		{
			$lin = $shape->line(0);
			$pt = $lin->point(0);
			if($pponto == "")
			{$pponto = $pt;}
			if (($prjTema != "") && ($prjMapa != $prjTema))
			{$pt->project($projInObj, $projOutObj);}
			$pontos[] = $pt->x;
			$pontos[] = $pt->y;
		}
		$pontos = implode(" ",$pontos);
		$pontos = xy2wkt($pontos);
		if ($para == "poligono")
		{$shape = ms_shapeObjFromWkt($pontos["poligono"]);}
		else
		{$shape = ms_shapeObjFromWkt($pontos["linha"]);}
		foreach ($items as $ni)
		{$reg[] = "-";}
		$novoshpf->addShape($shape);
		if($this->dbaseExiste == false)
		{
			xbase_add_record($db,$reg);
			xbase_close($db);
		}
		else
		{
			dbase_add_record($db,$reg);
			dbase_close($db);			
		}
		$novoshpf->free();
		$this->layer->close();
		//cria o novo layer
		$layer = criaLayer($this->mapa,MS_LAYER_LINE,MS_DEFAULT,"",$metaClasse="SIM");
		$layer->set("data",$nomeshp);
		$layer->setmetadata("tema",$novonomelayer." (linear)");
		$layer->setmetadata("download","sim");
		$layer->setmetadata("temalocal","sim");
		$classe = $layer->getclass(0);
		$estilo = $classe->getstyle(0);
		$estilo->set("symbolname","linha");
		if ($para == "poligono")
		{
			$layer->set("type",MS_LAYER_POLYGON);
			$layer->set("opacity","50");
			$layer->setmetadata("tema",$novonomelayer." (poligonal)");
		}
		return("ok");
	}
}
?>