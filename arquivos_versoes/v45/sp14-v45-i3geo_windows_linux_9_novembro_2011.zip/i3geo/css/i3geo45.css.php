<?php error_reporting(0);if(extension_loaded('zlib')){ob_start('ob_gzhandler');} header("Content-type: text/css"); ?>.paragrafo
{font-size:12px;line-height:15px;margin-bottom:9px;text-align:left;}
.lista td
{border: 0px solid rgb(240,240,240);border-left: 0px;border-right:0px;border-top:0px;padding: 0px;color:#2F4632;margin:0px;text-align:left;font-size: 11px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.lista2 td
{border: 0px solid rgb(240,240,240);border-left: 0px;border-right:0px;border-top:0px;padding: 2px;color:#2F4632;margin:0px;text-align:left;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.lista2 td input
{border:1px solid gray;}
.lista3 td
{border: 0px solid rgb(240,240,240);border-left: 0px;border-right:0px;border-top:0px;padding: 1px;color:#2F4632;background-color:#F2F2F2;margin:0px;text-align:left;font-size: 12px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.lista4 td
{border: 1px solid rgb(240,240,240);padding: 2px;color:#2F4632;margin:0px;text-align:left;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.lista4 td input
{border:0px solid gray;}
.lista5 td
{border: 0px solid rgb(240,240,240);border-left: 0px;border-right:0px;border-top:0px;padding: 2px;color:#2F4632;margin:0px;text-align:right;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.lista5 td input
{border:1px solid gray;}
.lista6 td
{border: 0px solid rgb(240,240,240);border-left: 0px;border-right:0px;border-top:0px;padding: 1px;color:#2F4632;background-color:white;margin:0px;text-align:left;font-size: 12px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.lista7 td
{border: 0px solid rgb(240,240,240);border-left: 0px;border-right:0px;border-top:0px;padding: 1px;color:#2F4632;background-color:#F2F2F2;margin:0px;text-align:left;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.lista8 td
{border-top: 1px solid rgb(240,240,240);padding: 2px;color:#2F4632;margin:0px;text-align:left;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.lista8 td input
{border:0px solid gray;}
.geralFerramentas
{position:relative;background-color:white;text-align:left;text-decoration:none;border-top: 2px solid rgb(230,230,230);font-family: Verdana, Arial, Helvetica, sans-serif;display:block;font-size:12px;padding:5px;font-weight:normal;top:8px;left:0px;overflow:auto;width:100%;}
.alerta
{color:red;font-size:11px;}
caption
{font-size:8px;padding-top:0px;border-top:0px solid #FFFFFF;z-index:1000;position:relative;}
span
{font-family: Verdana, Arial, Helvetica, sans-serif;}
body
{background-color:black;font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 12px;margin: 0px;z-index:1000;}
A
{text-align:left;font-size: 11px;font-family: Verdana, Arial, Helvetica, sans-serif;color: #2F4632;}
A:hover 
{color: #4142ff;font-weight: normal;font-family: Verdana, Arial, Helvetica, sans-serif;}
img
{border: 0px solid #FFFFFF;border-width:0;cursor:pointer}

table 
{text-align:center;border: 0px solid #FFFFFF;padding: 0px;margin:0px;font-family: Verdana, Arial, Helvetica, sans-serif;}
div
{text-align:center;border: 0px solid #FFFFFF;font-family: Verdana, Arial, Helvetica, sans-serif;position:relative;}
i 
{color:#660000;BACKGROUND-COLOR:#ffffcc;font-family: Verdana, Arial, Helvetica, sans-serif;}
P 
{COLOR: #2F4632;text-align: center;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;}
H1 
{COLOR: #2F4632;text-align:left;text-decoration: none;font-weight: normal;font-style: normal;font-size: 14px;font-family: Verdana, Arial, Helvetica, sans-serif;color: #004080;}
td 
{background-color:white;border: 0px solid gray;padding: 0px;color:#2F4632;margin:0px;text-align: center;font-size: 12px;font-family: Verdana, Arial, Helvetica, sans-serif;}
input
{font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;color: #2F4632;background-color: #FFFFFF;padding: 0;border: 1px solid gray;text-align: center;cursor: text;}
select
{font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;color: #2F4632;background-color: #FFFFFF;padding: 0;border: 1px solid gray;text-align: left;cursor: pointer;}

.ajuda_usuario
{
	background-image:url(../imagens/external.png);
	background-position:0px 0px;
	background-repeat:no-repeat;
	margin-left:0;
	text-decoration:none;
	cursor:help;
}

.executar
{cursor:pointer;color:white;text-align:left;background-color:gray;background-image:URL('../imagens/tic.png');background-repeat:no-repeat;border-style:outset;background-position: right;font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;}
.inputsb
{font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;color: #2F4632;background-color: #FFFFFF;padding: 0;border: 0px solid gray;text-align: center;cursor: text;}
.legendatemas
{cursor:pointer;text-align:left;background-color:transparent;vertical-align: top;border: 0px solid gray;margin:0;padding:0;font-family: Verdana, Arial, Helvetica, sans-serif;}
.legendatemas td
{text-align:left;background-color:#ffffff;vertical-align: top;padding: 0;font-family: Verdana, Arial, Helvetica, sans-serif;z-index:1000;position:relative;}
.legendatemas input
{cursor:pointer;vertical-align: top;font-family: Verdana, Arial, Helvetica, sans-serif;}
.legendadiv 
{left:0px;top:100px;overflow: auto;position: absolute;float: left;visibility:hidden;font-family: Verdana, Arial, Helvetica, sans-serif;}
.button
{visibility:visible;color: #2F4632;background: #ffffff;text-align: center;font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;border-style:outset;border-width:3px;cursor:pointer}
.filme
{cursor:pointer;text-align: center;font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 8px;color: #000000;background: #ebf8e9;border-style: solid;border-top-width: 1px;border-right-width: 0px;border-bottom-width: 1px;border-left-width: 0px;}
.direcao
{cursor:pointer;font-size: 0px;text-align: center;color: #ebf8e9;background-color: #d5e9c1;border: 0px solid #d5e9c1;font-family: Verdana, Arial, Helvetica, sans-serif;}
.pcenter10
{COLOR: #2F4632;text-align: center;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;z-index:1000;}
.tablefilme
{text-align:center;border: 0px solid #FFFFFF;padding: 0px;margin:0px;border-collapse: collapse;background:#ebf8e9;cursor:pointer;font-family: Verdana, Arial, Helvetica, sans-serif;z-index:1000;position:relative;}
.tablefilme td
{background-color:white;border: 0px solid #FFFFFF;padding: 0px;cursor:pointer;border-collapse: collapse;margin:0px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.tdclara
{color:#2F4632;border: 0px solid #DFDFDF;padding: 0px;background-color:#DFDFDF;margin:0px;text-align: center;font-size: 12px;font-family: Verdana, Arial, Helvetica, sans-serif;z-index:1000;position:relative;}
.tdbranca
{border-collapse: collapse;color:#2F4632;border: 0px solid #DFDFDF;padding: 0px;background-color:#FFFFFF;margin:0px;text-align: center;font-size: 12px;font-family: Verdana, Arial, Helvetica, sans-serif;z-index:1000;position:relative;}
.tdtxtleft
{color:#2F4632;border: 0px solid #DFDFDF;padding: 0px;background-color:#FFFFFF;margin:0px;text-align: left;font-size: 12px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.tdtxtjust
{color:#2F4632;border: 0px solid #DFDFDF;padding: 0px;background-color:#FFFFFF;margin:0px;text-align: justify;font-size: 12px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.verdeescuro 
{color:orange;border:0px solid #6699FF;padding:0px;background-color:#667B67;margin:0px;text-align: left;font-size: 8px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.verdeclaro
{background-image:url(../imagens/i3geo1bw.jpg);padding: 0px;background-color:#d5e9c1;margin:0px;border: 0px solid #d5e9c1;font-family: Verdana, Arial, Helvetica, sans-serif;z-index:1000;}
.verdemedio
{padding: 0px;background-color:#d5e9c1;margin:0px;border: 0px solid #d5e9c1;font-family: Verdana, Arial, Helvetica, sans-serif;z-index:1000;position:relative;}
.aplicar
{visibility:visible;color: #2F4632;background:rgb(240,240,240);text-align: center;font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 12px;border-style:outset;border-width:2px;border-color:#cc0000;cursor:pointer;z-index:1000;}
.digitar
{margin:0px;color:#426252;background-color:#F6F6F6;border: 1px solid #CBCBCB;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.digitarOver
{margin:0px;color:#426252;background-color:#F6F6F6;border: 1px solid white;border-bottom:1px solid gray;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;}

.digitarMouseclick
{margin:0px;color:#426252;background-color:beige;border: 1px solid white;border-bottom:1px solid gray;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;}
.digitarMouseover
{margin:0px;color:#426252;background-color:rgb(195,226,226);border: 0px solid #CBCBCB;font-size: 10px;font-family: Verdana, Arial, Helvetica, sans-serif;}

.legendaTema
{font-size:12px;text-align:left;}
#corpoMapa,#corpoMapaL,#corpoMapaO,#corpoMapaN,#corpoMapaS
{position:absolute;left:0px;top:0px;z-index:0;}
#div_d
{position:absolute;left:0px;top:0px;z-index:0;}
#executa
{visibility:visible;color: #2F4632;background:rgb(240,240,240);text-align: center;font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 12px;border-style:outset;border-width:2px;border-color:#cc0000;cursor:pointer;}
#imgh
{z-index:1000;}
#ferramentas1
{display:block;}
#ferramentas2
{display:none;}
#ferramentas3
{display:none;}
#ferramentas
{vertical-align:top;font-family: Verdana, Arial, Helvetica, sans-serif;text-align: center;background-color:white;z-index:1000;position:relative;}
#ferramentas input
{font-size: 10px;color: #2F4632;border-style: solid;border-top-width: 1px;border-right-width: 2px;border-bottom-width: 2px;border-left-width: 1px;cursor:pointer;font-family: Verdana, Arial, Helvetica, sans-serif;z-index:1000;}
#ferramentas table
{padding: 0px;border-spacing:0px;width:100%;font-family: Verdana, Arial, Helvetica, sans-serif;z-index:1000;position:relative;}
#ferramentas table td
{border: 0px solid #ebf8e9;font-size: 12px;background-color:white;font-family: Verdana, Arial, Helvetica, sans-serif;z-index:1000;}
#listaTemas,#legenda,#legendai,#corpoLegi,#listaPropriedades,
{overflow:auto;background-color:white;text-align:left;}
#ferr1
{background-color:rgb(255,255,255);}
#janelaMenu
{opacity:.80;background-color: #667B67;position: absolute;top: 0px;width: 150px;height: 200px;border: 0px solid #667B67;text-align:center;z-index:0;}
#janelaMenu div
{position: relative;width: 150px;z-index:10;cursor:pointer;background-color:orange;color:white;}
#areaRealce
{opacity:.20;background-color: white;position: absolute;top: 0px;width: 50px;height: 50px;border: 0px solid #667B67;z-index:1000;}
#tip
{border: 0px solid yellow; opacity:.90;}
.clique
{cursor:pointer;color:blue;}
.guiaobj
{text-align:left;text-decoration:none;border: 0px solid #ffffff;font-family: Verdana, Arial, Helvetica, sans-serif;position:relative;display:block;font-size:8px;padding:1;font-weight:normal;top:0px;width:95%;}
#mostradistancia
{z-index:2600;color:red;background-color:white;font-family: Verdana, Arial, Helvetica, sans-serif;font-size:10px;}
div.yui-b p {margin:0 0 .5em 0;color:#999;}
div.yui-b p strong {font-weight:bold;color:#000;}
div.yui-b p em {color:#000;}            
h1 {padding:.25em .5em;background-color:#ccc;}
#vertHandleDiv {cursor:pointer; width:20px; height:18px; position:absolute;left:-1;top:0px }
#vertBGDiv {position:relative;top:0px; width:18px; left:0px;background:url(../imagens/zoombar.png) no-repeat;height:78px; }

.yui-panel-container .yui-resizepanel .bd {

    overflow: auto;
    background-color: #fff;

}
.yui-panel-container.hide-scrollbars .yui-resizepanel .bd {
    overflow: hidden;
}
.yui-panel-container.show-scrollbars .yui-resizepanel .bd {
    overflow: auto;
}		
.yui-panel-container.show-scrollbars .underlay {
    overflow: visible;
}
.yui-resizepanel .resizehandle { 

     position: absolute; 
     width: 10px; 
     height: 10px; 
     right: 0;
     bottom: 0; 
     margin: 0; 
     padding: 0; 
     z-index: 3000; 
     background: url(../pacotes/yui270/build/container/img/corner_resize.gif) left bottom no-repeat;
     cursor: se-resize;
 }
/*hack opera */
@media all and (-webkit-min-device-pixel-ratio:10000), not all and (-webkit-min-device-pixel-ratio:0) 
{ .inputsb {border:1px solid black} }
/* esconde na impressao */
@media print {
	.noprint {display:none !important;}
	.yuimenubar  {display:none !important;}
	#i3GEOcompartilhar {display:none !important;}
	#i3GEOguiaMovel {display:none !important;}
	#localizarxy {display:none !important;}
}


#localizar,#barraedicao,#abregoogleearth,#uploadgpx,#metar,#carouselTemas,#identificaBalao,#rota,#buscafotos,#area,#confluence,#scielo,#wiki,#inseregrafico,#realca,#reinicia,#google,#zoomtot,#pan,#zoomli,#zoomlo,#zoomiauto,#zoomoauto,#identifica,#lentei,#reinicia,#exten,#selecao,#inserexy,#textofid,#mede,#perfil,#cruza,#tamanho,#imprimir,#salva,#carrega,#referencia,#pegaimagens,#v3d
{margin:2px;cursor:pointer;border: 0px solid rgb(50,50,50);border-bottom:1px solid rgb(50,50,50);border-left:1px solid rgb(50,50,50);width:24;height:24;z-index:1000;position:relative;}
#box1
{font-size:0px;cursor:crosshair;opacity:.25;background-color: gray;position: absolute;visibility: hidden;width: 0px;height: 0px;border: 2px solid #ff0000;}
#boxg
{position: absolute;visibility: visible;width: 20px;height: 20px;border: 2px solid red;display:none;}
#obj
{position:absolute;z-index:500;height:0;width: 0}
#lente
{z-index:101;top:10px;position: absolute;}
#boxlente
{display:none;z-index: 200;border: 2px solid #ff0000;top:10px;position:absolute;width: 240px;height: 240px;}
#aguarde
{top:0px;position:absolute;visibility: hidden;}
#mensagem
{background-color:white;position:absolute;visibility:hidden}
.i3geoBotaoAplicar
{display:none;position:absolute;cursor:pointer;z-index:1000;background-color:#F6F6F6;color:#426252;}

#img,#imgL,#imgO,#imgN,#imgS
{border: 0px solid black;cursor:crosshair;top:0px;left:0px;}
#img_d
{border: 0px solid black;cursor:crosshair;}
#carrega
{background-image:URL('../imagens/carrega.gif');}
#salva
{background-image:URL('../imagens/salva.gif');}
#tamanho
{background-image:URL('../imagens/amp.gif');}
#cruza
{background-image:URL('../imagens/cruzapt.png');}
#perfil
{background-image:URL('../imagens/perfil.gif');}
#pegaimagens
{background-image:URL('../imagens/legend.gif');}
#realca
{background-image:URL('../imagens/realca.gif');}
#zoomlo
{background-image:URL('../imagens/zoomlo.gif');}

#imprimir
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px 0px;
}
#mede
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -24px;
}
#textofid
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -48px;
}
#inserexy
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -72px;
}
#selecao
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -96px;
}
#exten
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -120px;
}
#reinicia
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -144px;
}
#lentei
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -168px;
}
#identificaBalao
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -192px;
	cursor:pointer;
}
#zoomtot
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -216px;
}
#pan
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -240px;
}
#google
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -264px;
}
#referencia
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -288px;
}
#inseregrafico
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -312px;
}
#wiki
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -336px;
}
#scielo
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -360px;
}
#confluence
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -384px;
}
#v3d
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -408px;
}
#area
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -432px;
}
#identifica
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -456px;
	cursor:pointer;
}
#metar
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -480px;
	cursor:pointer;
}
#buscafotos
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -504px;
	cursor:pointer;
}
#rota
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -528px;
}
.abregoogleearth
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -576px;

}
.ticPropriedades2
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
    background-position: -5px -603px;
    height: 15px;
    width: 15px;
}
.carregarKml
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -624px;
	width:16px;
	border: 1px solid #DCDCDC;
}
#barraedicao
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -648px;
}
#localizar
{
	background-image:URL('../imagens/visual/default/sprite2.png');
	background-repeat: no-repeat;
	background-position: 0px -672px;
}
#ondeestou
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -475px;
	width:20px;
	height:10px;
}
#menuinterface
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 3px -550px;
	width:52px;
	height:15px;
}
#menuajudaMenu
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 3px -500px;
	width:52px;
	height:15px;
}
#menuanalise
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 3px -525px;
	width:52px;
	height:15px;
}
#menujanelas
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 3px -550px;
	width:52px;
	height:15px;
}
#menuferramentas
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 3px -2157px;
	width:65px;
	height:15px;
}
#menuarquivos
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 3px -575px;
	width:52px;
	height:15px;
}
/*bandeira do brasil*/
#brasil
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -600px;
	width:20px;
	height:10px;
	cursor:pointer;
}
/*bandeira inglaterra*/
#uk
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -625px;
	width:20px;
	height:10px;
	cursor:pointer;
}
#espanhol
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1400px;
	width:20px;
	height:10px;
	cursor:pointer;
}
#italiano
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1725px;
	width:20px;
	height:10px;
	cursor:pointer;
}

/*�cone de aplicar*/
.tic
{
	background-image:url(../imagens/visual/default/sprite.png);
	background-position:0px -650px;
	background-repeat:no-repeat;
	cursor:pointer;
	height:14px;
	text-align:center;
	width:25px;
}
.x
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -675px;
	width:9px;
	height:9px;
	cursor:pointer;
}
.sobe
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -700px;
	width:9px;
	height:9px;
	cursor:pointer;
}
.desce
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -725px;
	width:9px;
	height:9px;
	cursor:pointer;
}
.extent
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -750px;
	width:9px;
	height:9px;
	cursor:pointer;
}
.menuarrow
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -775px;
	width:16px;
	height:16px;
	cursor:pointer;
	left:3px;
	top:2px;
}
.mais
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -800px;
	width:17px;
	height:9px;
	cursor:pointer;
}
.menos
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -825px;
	width:17px;
	height:9px;
	cursor:pointer;
}
.ponto
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -850px;
	width:17px;
	height:9px;
	cursor:pointer;
}
.quadro
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -875px;
	width:13px;
	height:13px;
	cursor:pointer;
}
.quadro1
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -900px;
	width:13px;
	height:13px;
	cursor:pointer;
}
.slider
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -925px;
	width:20px;
	height:9px;
}
#vertMenosZoom
{
	cursor:pointer;
	position:relative;
	top:-1px; 
	width:18px; 
	background:url('../imagens/visual/default/sprite.png');
	background-position: 0px -950px;
	height:18px;
}
#vertMaisZoom
{
	cursor:pointer;
	position:relative;
	top:2px;
	width:18px;
	background:url('../imagens/visual/default/sprite.png');
	background-position: 0px -975px;
	height:18px;
}
#zoomli
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1000px;
}
.foldermapa1
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1025px;
	width:17px;
	height:15px;
}
.foldermapa
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1050px;
	width:17px;
	height:15px;
}
#i3geo_lixeira
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1078px;
	width:14px;
	height:18px;
}
.upload
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1099px;
	width:16px;
	border: 1px solid #DCDCDC;
}
.download
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1124px;
	width:16px;
	border: 1px solid #DCDCDC;
}
.conectarwms
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 1px -1149px;
	width:16px;
	border: 1px solid #DCDCDC;
}
.conectargeorss
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 1px -1174px;
	width:16px;
	border: 1px solid #DCDCDC;
}
.conectarservidor
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1200px;
	width:14px;
	height:14px;
	border-left: 1px solid gray;
	border-bottom:1px solid gray;
	border-top:1px solid #F8F8F8;
	border-right:1px solid #F8F8F8;
}
.folder
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1225px;
	width:17px;
	height:15px;
}
.rosanorte
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1250px;
	width:14px;
	height:14px;
}
.rosasul
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1275px;
	width:14px;
	height:14px;
}
.rosaleste
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1300px;
	width:14px;
	height:14px;
}
.rosaoeste
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1325px;
	width:14px;
	height:14px;
}
.rosamais
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1350px;
	width:10px;
	height:20px;
}
.rosamenos
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1375px;
	width:10px;
	height:20px;
}
#desceferramentas
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1450px;
	cursor:pointer;
	width:22px;
	height:20px;
	margin: 2px;
}
#sobeferramentas
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1475px;
	cursor:pointer;
	width:22px;
	height:20px;
	margin: 2px;
}
/*marcador de lista das propriedades do mapa*/
.ticPropriedades
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1500px;
	width:9px;
	height:10px;
	cursor:pointer;
	margin-right:3px;
}
/*marcador de lista das op��es do tema*/
.ticOpcoesTemas
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1500px;
	width:9px;
	height:10px;
	cursor:pointer;
	margin-right:3px;
}
.uploaddbf
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 1px -1523px;
	width:16px;
	border: 1px solid #DCDCDC;
}
.rosanordeste
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1550px;
	width:14px;
	height:14px;
}
.rosasudeste
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1575px;
	width:14px;
	height:14px;
}
.rosanoroeste
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1600px;
	width:14px;
	height:14px;
}
.rosasudoeste
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1625px;
	width:14px;
	height:14px;
}
.nuvemtags
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 1px -1648px;
	width:16px;
	border: 1px solid #DCDCDC;
}
.zoomAnterior
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1675px;
	width:10px;
	height:11px;
	cursor:pointer;
}
.zoomProximo
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1700px;
	width:10px;
	height:11px;
	cursor:pointer;
}
.refresh
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1749px;
	width:18px;
	height:20px;
	cursor:pointer;
}

.conectarwmst
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 1px -1824px;
	width:16px;
	border: 1px solid #DCDCDC;
}
.fonte
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1850px;
	width:9px;
	height:9px;
	cursor:pointer;
}
#zoomiauto
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1875px;
	cursor:pointer;
}
#zoomoauto
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1900px;
	cursor:pointer;
}
#olhoAberto
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1925px;
	cursor:pointer;
	width:25px;
	height:20px;
}
#olhoFechado
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -1949px;
	width:25px;
	height:20px;
	cursor:pointer;
}
.carouselTemas
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -2000px;
	width: 16px;
	border: 1px solid #DCDCDC;
	cursor:pointer;
}
.uploadgpx
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -2052px;
	width: 16px;
	border: 1px solid #DCDCDC;
	cursor:pointer;
}
#i3geo_filtro
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -2075px;
	width:16px;
	height:16px;
}
#soltaLeg
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -2100px;
	cursor:pointer;
	width:22px;
	height:22px;
}
#soltaLeg2
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -2125px;
	cursor:pointer;
	width:16px;
	height:16px;
}
#opacidadeMapa
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -2175px;
	cursor:pointer;
	width:16px;
	height:16px;
}
#animaMapa
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -2190px;
	cursor:pointer;
	width:16px;
	height:16px;
}

.importarwmc
{
	background-image:URL('../imagens/visual/default/sprite.png');
	background-repeat: no-repeat;
	background-position: 0px -2140px;
	border: 1px solid #DCDCDC;
	cursor:pointer;
	width:16px;
}

button{background:url(../imagens/tic2.png) 98% 50% no-repeat;}
#encolheFerramentas
{background-image:URL('../imagens/encolhe.png');background-repeat: no-repeat;background-position:center;cursor:pointer;}ul	{text-align:left;list-style-type:none;padding-left: 15px;margin-left:5px; margin-top:15px;}
li	{margin-top:-10px;margin-bottom:15px;}
.toc {margin-left: 15px;}
.details {margin-left: 5px;}
h3	{ margin-top:0px; margin-bottom:0px; font-size:18px; color: #3B6BD2;}
.sample {padding-left: 10px; font-size: 12px; margin-bottom: 25px; padding-bottom: 5px; border-bottom: 5px solid #3B6BD2;}
.description {padding-left: 10px; font-size: 12px; margin-top: 10px; margin-bottom: 25px; padding-bottom: 5px; border-bottom: 1px dotted gray;}
.header {background-color: #5B84EE; padding-top:3px;padding-bottom:3px;padding-left:3px;padding-right:3px; border: 1px solid #C0C0C0; }
.footer {background-color: #E4E4E4;padding-top:3px;padding-bottom:3px;padding-left:10px;padding-right:3px; border: 1px solid #C0C0C0; }
.code	{background-color: #F1F1F1; font-family: Courier New; font-size: 9pt; color: #000080; padding: 5px;}
.function	{width:94%; background-color: #C0C0C0; border: 1px solid #A0A0A0; padding: 5px;font-family: Courier New; font-size: 9pt;}
body	{font-size: 8pt;}
td	{font-size: 8pt;}
th	{font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 8pt;}
.ftable	{padding-top:5px;padding-bottom:5px;padding-left:5px;padding-right:5px;}
input { font-size: 11px; }
select { font-size: 11px; }
/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
.yui-skin-sam .yui-log{padding:1em;width:31em;background-color:#AAA;color:#000;border:1px solid black;font-family:monospace;font-size:77%;text-align:left;z-index:9000;}.yui-skin-sam .yui-log-container{position:absolute;top:1em;right:1em;}.yui-skin-sam .yui-log input{margin:0;padding:0;font-family:arial;font-size:100%;font-weight:normal;}.yui-skin-sam .yui-log .yui-log-btns{position:relative;float:right;bottom:.25em;}.yui-skin-sam .yui-log .yui-log-hd{margin-top:1em;padding:.5em;background-color:#575757;}.yui-skin-sam .yui-log .yui-log-hd h4{margin:0;padding:0;font-size:108%;font-weight:bold;color:#FFF;}.yui-skin-sam .yui-log .yui-log-bd{width:100%;height:20em;background-color:#FFF;border:1px solid gray;overflow:auto;}.yui-skin-sam .yui-log p{margin:1px;padding:.1em;}.yui-skin-sam .yui-log pre{margin:0;padding:0;}.yui-skin-sam .yui-log pre.yui-log-verbose{white-space:pre-wrap;white-space:-moz-pre-wrap !important;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word;}.yui-skin-sam .yui-log .yui-log-ft{margin-top:.5em;}.yui-skin-sam .yui-log .yui-log-ft .yui-log-categoryfilters{}.yui-skin-sam .yui-log .yui-log-ft .yui-log-sourcefilters{width:100%;border-top:1px solid #575757;margin-top:.75em;padding-top:.75em;}.yui-skin-sam .yui-log .yui-log-filtergrp{margin-right:.5em;}.yui-skin-sam .yui-log .info{background-color:#A7CC25;}.yui-skin-sam .yui-log .warn{background-color:#F58516;}.yui-skin-sam .yui-log .error{background-color:#E32F0B;}.yui-skin-sam .yui-log .time{background-color:#A6C9D7;}.yui-skin-sam .yui-log .window{background-color:#F2E886;}
/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
body{font:13px/1.231 arial,helvetica,clean,sans-serif;*font-size:small;*font:x-small;}select,input,button,textarea,button{font:99% arial,helvetica,clean,sans-serif;}table{font-size:inherit;font:100%;}pre,code,kbd,samp,tt{font-family:monospace;*font-size:108%;line-height:100%;}/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
html{color:#000;background:#FFF;}body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,code,form,fieldset,legend,input,button,textarea,p,blockquote,th,td{margin:0;padding:0;}table{border-collapse:collapse;border-spacing:0;}fieldset,img{border:0;}address,caption,cite,code,dfn,em,strong,th,var,optgroup{font-style:inherit;font-weight:inherit;}del,ins{text-decoration:none;}li{list-style:none;}caption,th{text-align:left;}h1,h2,h3,h4,h5,h6{font-size:100%;font-weight:normal;}q:before,q:after{content:'';}abbr,acronym{border:0;font-variant:normal;}sup{vertical-align:baseline;}sub{vertical-align:baseline;}legend{color:#000;}input,button,textarea,select,optgroup,option{font-family:inherit;font-size:inherit;font-style:inherit;font-weight:inherit;}input,button,textarea,select{*font-size:100%;}body{font:13px/1.231 arial,helvetica,clean,sans-serif;*font-size:small;*font:x-small;}select,input,button,textarea,button{font:99% arial,helvetica,clean,sans-serif;}table{font-size:inherit;font:100%;}pre,code,kbd,samp,tt{font-family:monospace;*font-size:108%;line-height:100%;}body{text-align:center;}#doc,#doc2,#doc3,#doc4,.yui-t1,.yui-t2,.yui-t3,.yui-t4,.yui-t5,.yui-t6,.yui-t7{margin:auto;text-align:left;width:57.69em;*width:56.25em;}#doc2{width:73.076em;*width:71.25em;}#doc3{margin:auto 10px;width:auto;}#doc4{width:74.923em;*width:73.05em;}.yui-b{position:relative;}.yui-b{_position:static;}#yui-main .yui-b{position:static;}#yui-main,.yui-g .yui-u .yui-g{width:100%;}.yui-t1 #yui-main,.yui-t2 #yui-main,.yui-t3 #yui-main{float:right;margin-left:-25em;}.yui-t4 #yui-main,.yui-t5 #yui-main,.yui-t6 #yui-main{float:left;margin-right:-25em;}.yui-t1 .yui-b{float:left;width:12.30769em;*width:12.00em;}.yui-t1 #yui-main .yui-b{margin-left:13.30769em;*margin-left:13.05em;}.yui-t2 .yui-b{float:left;width:13.8461em;*width:13.50em;}.yui-t2 #yui-main .yui-b{margin-left:14.8461em;*margin-left:14.55em;}.yui-t3 .yui-b{float:left;width:23.0769em;*width:22.50em;}.yui-t3 #yui-main .yui-b{margin-left:24.0769em;*margin-left:23.62em;}.yui-t4 .yui-b{float:right;width:13.8456em;*width:13.50em;}.yui-t4 #yui-main .yui-b{margin-right:14.8456em;*margin-right:14.55em;}.yui-t5 .yui-b{float:right;width:18.4615em;*width:18.00em;}.yui-t5 #yui-main .yui-b{margin-right:19.4615em;*margin-right:19.125em;}.yui-t6 .yui-b{float:right;width:23.0769em;*width:22.50em;}.yui-t6 #yui-main .yui-b{margin-right:24.0769em;*margin-right:23.62em;}.yui-t7 #yui-main .yui-b{display:block;margin:0 0 1em 0;}#yui-main .yui-b{float:none;width:auto;}.yui-gb .yui-u,.yui-g .yui-gb .yui-u,.yui-gb .yui-g,.yui-gb .yui-gb,.yui-gb .yui-gc,.yui-gb .yui-gd,.yui-gb .yui-ge,.yui-gb .yui-gf,.yui-gc .yui-u,.yui-gc .yui-g,.yui-gd .yui-u{float:left;}.yui-g .yui-u,.yui-g .yui-g,.yui-g .yui-gb,.yui-g .yui-gc,.yui-g .yui-gd,.yui-g .yui-ge,.yui-g .yui-gf,.yui-gc .yui-u,.yui-gd .yui-g,.yui-g .yui-gc .yui-u,.yui-ge .yui-u,.yui-ge .yui-g,.yui-gf .yui-g,.yui-gf .yui-u{float:right;}.yui-g div.first,.yui-gb div.first,.yui-gc div.first,.yui-gd div.first,.yui-ge div.first,.yui-gf div.first,.yui-g .yui-gc div.first,.yui-g .yui-ge div.first,.yui-gc div.first div.first{float:left;}.yui-g .yui-u,.yui-g .yui-g,.yui-g .yui-gb,.yui-g .yui-gc,.yui-g .yui-gd,.yui-g .yui-ge,.yui-g .yui-gf{width:49.1%;}.yui-gb .yui-u,.yui-g .yui-gb .yui-u,.yui-gb .yui-g,.yui-gb .yui-gb,.yui-gb .yui-gc,.yui-gb .yui-gd,.yui-gb .yui-ge,.yui-gb .yui-gf,.yui-gc .yui-u,.yui-gc .yui-g,.yui-gd .yui-u{width:32%;margin-left:1.99%;}.yui-gb .yui-u{*margin-left:1.9%;*width:31.9%;}.yui-gc div.first,.yui-gd .yui-u{width:66%;}.yui-gd div.first{width:32%;}.yui-ge div.first,.yui-gf .yui-u{width:74.2%;}.yui-ge .yui-u,.yui-gf div.first{width:24%;}.yui-g .yui-gb div.first,.yui-gb div.first,.yui-gc div.first,.yui-gd div.first{margin-left:0;}.yui-g .yui-g .yui-u,.yui-gb .yui-g .yui-u,.yui-gc .yui-g .yui-u,.yui-gd .yui-g .yui-u,.yui-ge .yui-g .yui-u,.yui-gf .yui-g .yui-u{width:49%;*width:48.1%;*margin-left:0;}.yui-g .yui-g .yui-u{width:48.1%;}.yui-g .yui-gb div.first,.yui-gb .yui-gb div.first{*margin-right:0;*width:32%;_width:31.7%;}.yui-g .yui-gc div.first,.yui-gd .yui-g{width:66%;}.yui-gb .yui-g div.first{*margin-right:4%;_margin-right:1.3%;}.yui-gb .yui-gc div.first,.yui-gb .yui-gd div.first{*margin-right:0;}.yui-gb .yui-gb .yui-u,.yui-gb .yui-gc .yui-u{*margin-left:1.8%;_margin-left:4%;}.yui-g .yui-gb .yui-u{_margin-left:1.0%;}.yui-gb .yui-gd .yui-u{*width:66%;_width:61.2%;}.yui-gb .yui-gd div.first{*width:31%;_width:29.5%;}.yui-g .yui-gc .yui-u,.yui-gb .yui-gc .yui-u{width:32%;_float:right;margin-right:0;_margin-left:0;}.yui-gb .yui-gc div.first{width:66%;*float:left;*margin-left:0;}.yui-gb .yui-ge .yui-u,.yui-gb .yui-gf .yui-u{margin:0;}.yui-gb .yui-gb .yui-u{_margin-left:.7%;}.yui-gb .yui-g div.first,.yui-gb .yui-gb div.first{*margin-left:0;}.yui-gc .yui-g .yui-u,.yui-gd .yui-g .yui-u{*width:48.1%;*margin-left:0;}.yui-gb .yui-gd div.first{width:32%;}.yui-g .yui-gd div.first{_width:29.9%;}.yui-ge .yui-g{width:24%;}.yui-gf .yui-g{width:74.2%;}.yui-gb .yui-ge div.yui-u,.yui-gb .yui-gf div.yui-u{float:right;}.yui-gb .yui-ge div.first,.yui-gb .yui-gf div.first{float:left;}.yui-gb .yui-ge .yui-u,.yui-gb .yui-gf div.first{*width:24%;_width:20%;}.yui-gb .yui-ge div.first,.yui-gb .yui-gf .yui-u{*width:73.5%;_width:65.5%;}.yui-ge div.first .yui-gd .yui-u{width:65%;}.yui-ge div.first .yui-gd div.first{width:32%;}#hd:after,#bd:after,#ft:after,.yui-g:after,.yui-gb:after,.yui-gc:after,.yui-gd:after,.yui-ge:after,.yui-gf:after{content:".";display:block;height:0;clear:both;visibility:hidden;}#hd,#bd,#ft,.yui-g,.yui-gb,.yui-gc,.yui-gd,.yui-ge,.yui-gf{zoom:1;}/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
body{text-align:center;}#doc,#doc2,#doc3,#doc4,.yui-t1,.yui-t2,.yui-t3,.yui-t4,.yui-t5,.yui-t6,.yui-t7{margin:auto;text-align:left;width:57.69em;*width:56.25em;}#doc2{width:73.076em;*width:71.25em;}#doc3{margin:auto 10px;width:auto;}#doc4{width:74.923em;*width:73.05em;}.yui-b{position:relative;}.yui-b{_position:static;}#yui-main .yui-b{position:static;}#yui-main,.yui-g .yui-u .yui-g{width:100%;}.yui-t1 #yui-main,.yui-t2 #yui-main,.yui-t3 #yui-main{float:right;margin-left:-25em;}.yui-t4 #yui-main,.yui-t5 #yui-main,.yui-t6 #yui-main{float:left;margin-right:-25em;}.yui-t1 .yui-b{float:left;width:12.30769em;*width:12.00em;}.yui-t1 #yui-main .yui-b{margin-left:13.30769em;*margin-left:13.05em;}.yui-t2 .yui-b{float:left;width:13.8461em;*width:13.50em;}.yui-t2 #yui-main .yui-b{margin-left:14.8461em;*margin-left:14.55em;}.yui-t3 .yui-b{float:left;width:23.0769em;*width:22.50em;}.yui-t3 #yui-main .yui-b{margin-left:24.0769em;*margin-left:23.62em;}.yui-t4 .yui-b{float:right;width:13.8456em;*width:13.50em;}.yui-t4 #yui-main .yui-b{margin-right:14.8456em;*margin-right:14.55em;}.yui-t5 .yui-b{float:right;width:18.4615em;*width:18.00em;}.yui-t5 #yui-main .yui-b{margin-right:19.4615em;*margin-right:19.125em;}.yui-t6 .yui-b{float:right;width:23.0769em;*width:22.50em;}.yui-t6 #yui-main .yui-b{margin-right:24.0769em;*margin-right:23.62em;}.yui-t7 #yui-main .yui-b{display:block;margin:0 0 1em 0;}#yui-main .yui-b{float:none;width:auto;}.yui-gb .yui-u,.yui-g .yui-gb .yui-u,.yui-gb .yui-g,.yui-gb .yui-gb,.yui-gb .yui-gc,.yui-gb .yui-gd,.yui-gb .yui-ge,.yui-gb .yui-gf,.yui-gc .yui-u,.yui-gc .yui-g,.yui-gd .yui-u{float:left;}.yui-g .yui-u,.yui-g .yui-g,.yui-g .yui-gb,.yui-g .yui-gc,.yui-g .yui-gd,.yui-g .yui-ge,.yui-g .yui-gf,.yui-gc .yui-u,.yui-gd .yui-g,.yui-g .yui-gc .yui-u,.yui-ge .yui-u,.yui-ge .yui-g,.yui-gf .yui-g,.yui-gf .yui-u{float:right;}.yui-g div.first,.yui-gb div.first,.yui-gc div.first,.yui-gd div.first,.yui-ge div.first,.yui-gf div.first,.yui-g .yui-gc div.first,.yui-g .yui-ge div.first,.yui-gc div.first div.first{float:left;}.yui-g .yui-u,.yui-g .yui-g,.yui-g .yui-gb,.yui-g .yui-gc,.yui-g .yui-gd,.yui-g .yui-ge,.yui-g .yui-gf{width:49.1%;}.yui-gb .yui-u,.yui-g .yui-gb .yui-u,.yui-gb .yui-g,.yui-gb .yui-gb,.yui-gb .yui-gc,.yui-gb .yui-gd,.yui-gb .yui-ge,.yui-gb .yui-gf,.yui-gc .yui-u,.yui-gc .yui-g,.yui-gd .yui-u{width:32%;margin-left:1.99%;}.yui-gb .yui-u{*margin-left:1.9%;*width:31.9%;}.yui-gc div.first,.yui-gd .yui-u{width:66%;}.yui-gd div.first{width:32%;}.yui-ge div.first,.yui-gf .yui-u{width:74.2%;}.yui-ge .yui-u,.yui-gf div.first{width:24%;}.yui-g .yui-gb div.first,.yui-gb div.first,.yui-gc div.first,.yui-gd div.first{margin-left:0;}.yui-g .yui-g .yui-u,.yui-gb .yui-g .yui-u,.yui-gc .yui-g .yui-u,.yui-gd .yui-g .yui-u,.yui-ge .yui-g .yui-u,.yui-gf .yui-g .yui-u{width:49%;*width:48.1%;*margin-left:0;}.yui-g .yui-g .yui-u{width:48.1%;}.yui-g .yui-gb div.first,.yui-gb .yui-gb div.first{*margin-right:0;*width:32%;_width:31.7%;}.yui-g .yui-gc div.first,.yui-gd .yui-g{width:66%;}.yui-gb .yui-g div.first{*margin-right:4%;_margin-right:1.3%;}.yui-gb .yui-gc div.first,.yui-gb .yui-gd div.first{*margin-right:0;}.yui-gb .yui-gb .yui-u,.yui-gb .yui-gc .yui-u{*margin-left:1.8%;_margin-left:4%;}.yui-g .yui-gb .yui-u{_margin-left:1.0%;}.yui-gb .yui-gd .yui-u{*width:66%;_width:61.2%;}.yui-gb .yui-gd div.first{*width:31%;_width:29.5%;}.yui-g .yui-gc .yui-u,.yui-gb .yui-gc .yui-u{width:32%;_float:right;margin-right:0;_margin-left:0;}.yui-gb .yui-gc div.first{width:66%;*float:left;*margin-left:0;}.yui-gb .yui-ge .yui-u,.yui-gb .yui-gf .yui-u{margin:0;}.yui-gb .yui-gb .yui-u{_margin-left:.7%;}.yui-gb .yui-g div.first,.yui-gb .yui-gb div.first{*margin-left:0;}.yui-gc .yui-g .yui-u,.yui-gd .yui-g .yui-u{*width:48.1%;*margin-left:0;}.yui-gb .yui-gd div.first{width:32%;}.yui-g .yui-gd div.first{_width:29.9%;}.yui-ge .yui-g{width:24%;}.yui-gf .yui-g{width:74.2%;}.yui-gb .yui-ge div.yui-u,.yui-gb .yui-gf div.yui-u{float:right;}.yui-gb .yui-ge div.first,.yui-gb .yui-gf div.first{float:left;}.yui-gb .yui-ge .yui-u,.yui-gb .yui-gf div.first{*width:24%;_width:20%;}.yui-gb .yui-ge div.first,.yui-gb .yui-gf .yui-u{*width:73.5%;_width:65.5%;}.yui-ge div.first .yui-gd .yui-u{width:65%;}.yui-ge div.first .yui-gd div.first{width:32%;}#hd:after,#bd:after,#ft:after,.yui-g:after,.yui-gb:after,.yui-gc:after,.yui-gd:after,.yui-ge:after,.yui-gf:after{content:".";display:block;height:0;clear:both;visibility:hidden;}#hd,#bd,#ft,.yui-g,.yui-gb,.yui-gc,.yui-gd,.yui-ge,.yui-gf{zoom:1;}/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
.yuimenu{top:-999em;left:-999em;}.yuimenubar{position:static;}.yuimenu .yuimenu,.yuimenubar .yuimenu{position:absolute;}.yuimenubar li,.yuimenu li{list-style-type:none;}.yuimenubar ul,.yuimenu ul,.yuimenubar li,.yuimenu li,.yuimenu h6,.yuimenubar h6{margin:0;padding:0;}.yuimenuitemlabel,.yuimenubaritemlabel{text-align:left;white-space:nowrap;}.yuimenubar ul{*zoom:1;}.yuimenubar .yuimenu ul{*zoom:normal;}.yuimenubar>.bd>ul:after{content:".";display:block;clear:both;visibility:hidden;height:0;line-height:0;}.yuimenubaritem{float:left;}.yuimenubaritemlabel,.yuimenuitemlabel{display:block;}.yuimenuitemlabel .helptext{font-style:normal;display:block;margin:-1em 0 0 10em;}.yui-menu-shadow{position:absolute;visibility:hidden;z-index:-1;}.yui-menu-shadow-visible{top:2px;right:-3px;left:-3px;bottom:-3px;visibility:visible;}.hide-scrollbars *{overflow:hidden;}.hide-scrollbars select{display:none;}.yuimenu.show-scrollbars,.yuimenubar.show-scrollbars{overflow:visible;}.yuimenu.hide-scrollbars .yui-menu-shadow,.yuimenubar.hide-scrollbars .yui-menu-shadow{overflow:hidden;}.yuimenu.show-scrollbars .yui-menu-shadow,.yuimenubar.show-scrollbars .yui-menu-shadow{overflow:auto;}.yui-overlay.yui-force-redraw{margin-bottom:1px;}.yui-skin-sam .yuimenubar{font-size:93%;line-height:2;*line-height:1.9;border:solid 1px #808080;background:url(../../../../assets/skins/sam/sprite.png) repeat-x 0 0;}.yui-skin-sam .yuimenubarnav .yuimenubaritem{border-right:solid 1px #ccc;}.yui-skin-sam .yuimenubaritemlabel{padding:0 10px;color:#000;text-decoration:none;cursor:default;border-style:solid;border-color:#808080;border-width:1px 0;*position:relative;margin:-1px 0;}.yui-skin-sam .yuimenubarnav .yuimenubaritemlabel{padding-right:20px;*display:inline-block;}.yui-skin-sam .yuimenubarnav .yuimenubaritemlabel-hassubmenu{background:url(menubaritem_submenuindicator.png) right center no-repeat;}.yui-skin-sam .yuimenubaritem-selected{background:url(../../../../assets/skins/sam/sprite.png) repeat-x 0 -1700px;}.yui-skin-sam .yuimenubaritemlabel-selected{border-color:#7D98B8;}.yui-skin-sam .yuimenubarnav .yuimenubaritemlabel-selected{border-left-width:1px;margin-left:-1px;*left:-1px;}.yui-skin-sam .yuimenubaritemlabel-disabled{cursor:default;color:#A6A6A6;}.yui-skin-sam .yuimenubarnav .yuimenubaritemlabel-hassubmenu-disabled{background-image:url(menubaritem_submenuindicator_disabled.png);}.yui-skin-sam .yuimenu{font-size:93%;line-height:1.5;*line-height:1.45;}.yui-skin-sam .yuimenubar .yuimenu,.yui-skin-sam .yuimenu .yuimenu{font-size:100%;}.yui-skin-sam .yuimenu .bd{*zoom:1;_zoom:normal;border:solid 1px #808080;background-color:#fff;}.yui-skin-sam .yuimenu .yuimenu .bd{*zoom:normal;}.yui-skin-sam .yuimenu ul{padding:3px 0;border-width:1px 0 0 0;border-color:#ccc;border-style:solid;}.yui-skin-sam .yuimenu ul.first-of-type{border-width:0;}.yui-skin-sam .yuimenu h6{font-weight:bold;border-style:solid;border-color:#ccc;border-width:1px 0 0 0;color:#a4a4a4;padding:3px 10px 0 10px;}.yui-skin-sam .yuimenu ul.hastitle,.yui-skin-sam .yuimenu h6.first-of-type{border-width:0;}.yui-skin-sam .yuimenu .yui-menu-body-scrolled{border-color:#ccc #808080;overflow:hidden;}.yui-skin-sam .yuimenu .topscrollbar,.yui-skin-sam .yuimenu .bottomscrollbar{height:16px;border:solid 1px #808080;background:#fff url(../../../../assets/skins/sam/sprite.png) no-repeat 0 0;}.yui-skin-sam .yuimenu .topscrollbar{border-bottom-width:0;background-position:center -950px;}.yui-skin-sam .yuimenu .topscrollbar_disabled{background-position:center -975px;}.yui-skin-sam .yuimenu .bottomscrollbar{border-top-width:0;background-position:center -850px;}.yui-skin-sam .yuimenu .bottomscrollbar_disabled{background-position:center -875px;}.yui-skin-sam .yuimenuitem{_border-bottom:solid 1px #fff;}.yui-skin-sam .yuimenuitemlabel{padding:0 20px;color:#000;text-decoration:none;cursor:default;}.yui-skin-sam .yuimenuitemlabel .helptext{margin-top:-1.5em;*margin-top:-1.45em;}.yui-skin-sam .yuimenuitem-hassubmenu{background-image:url(menuitem_submenuindicator.png);background-position:right center;background-repeat:no-repeat;}.yui-skin-sam .yuimenuitem-checked{background-image:url(menuitem_checkbox.png);background-position:left center;background-repeat:no-repeat;}.yui-skin-sam .yui-menu-shadow-visible{background-color:#000;opacity:.12;filter:alpha(opacity=12);}.yui-skin-sam .yuimenuitem-selected{background-color:#B3D4FF;}.yui-skin-sam .yuimenuitemlabel-disabled{cursor:default;color:#A6A6A6;}.yui-skin-sam .yuimenuitem-hassubmenu-disabled{background-image:url(menuitem_submenuindicator_disabled.png);}.yui-skin-sam .yuimenuitem-checked-disabled{background-image:url(menuitem_checkbox_disabled.png);}
/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
.yui-skin-sam .yui-ac{position:relative;font-family:arial;font-size:100%;}.yui-skin-sam .yui-ac-input{position:absolute;width:100%;}.yui-skin-sam .yui-ac-container{position:absolute;top:1.6em;width:100%;}.yui-skin-sam .yui-ac-content{position:absolute;width:100%;border:1px solid #808080;background:#fff;overflow:hidden;z-index:9050;}.yui-skin-sam .yui-ac-shadow{position:absolute;margin:.3em;width:100%;background:#000;-moz-opacity:.10;opacity:.10;filter:alpha(opacity=10);z-index:9049;}.yui-skin-sam .yui-ac iframe{opacity:0;filter:alpha(opacity=0);padding-right:.3em;padding-bottom:.3em;}.yui-skin-sam .yui-ac-content ul{margin:0;padding:0;width:100%;}.yui-skin-sam .yui-ac-content li{margin:0;padding:2px 5px;cursor:default;white-space:nowrap;list-style:none;zoom:1;}.yui-skin-sam .yui-ac-content li.yui-ac-prehighlight{background:#B3D4FF;}.yui-skin-sam .yui-ac-content li.yui-ac-highlight{background:#426FD9;color:#FFF;}
/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
.yui-overlay,.yui-panel-container{visibility:hidden;position:absolute;z-index:2;}.yui-panel{position:relative;}.yui-panel-container form{margin:0;}.mask{z-index:1;display:none;position:absolute;top:0;left:0;right:0;bottom:0;}.mask.block-scrollbars{overflow:auto;}.masked select,.drag select,.hide-select select{_visibility:hidden;}.yui-panel-container select{_visibility:inherit;}.hide-scrollbars,.hide-scrollbars *{overflow:hidden;}.hide-scrollbars select{display:none;}.show-scrollbars{overflow:auto;}.yui-panel-container.show-scrollbars,.yui-tt.show-scrollbars{overflow:visible;}.yui-panel-container.show-scrollbars .underlay,.yui-tt.show-scrollbars .yui-tt-shadow{overflow:auto;}.yui-panel-container.shadow .underlay.yui-force-redraw{padding-bottom:1px;}.yui-effect-fade .underlay,.yui-effect-fade .yui-tt-shadow{display:none;}.yui-tt-shadow{position:absolute;}.yui-override-padding{padding:0!important;}.yui-panel-container .container-close{overflow:hidden;text-indent:-10000em;text-decoration:none;}.yui-overlay.yui-force-redraw,.yui-panel-container.yui-force-redraw{margin-bottom:1px;}.yui-skin-sam .mask{background-color:#000;opacity:.25;filter:alpha(opacity=25);}.yui-skin-sam .yui-panel-container{padding:0 1px;*padding:2px;}.yui-skin-sam .yui-panel{position:relative;left:0;top:0;border-style:solid;border-width:1px 0;border-color:#808080;z-index:1;*border-width:1px;*zoom:1;_zoom:normal;}.yui-skin-sam .yui-panel .hd,.yui-skin-sam .yui-panel .bd,.yui-skin-sam .yui-panel .ft{border-style:solid;border-width:0 1px;border-color:#808080;margin:0 -1px;*margin:0;*border:0;}.yui-skin-sam .yui-panel .hd{border-bottom:solid 1px #ccc;}.yui-skin-sam .yui-panel .bd,.yui-skin-sam .yui-panel .ft{background-color:#F2F2F2;}.yui-skin-sam .yui-panel .hd{padding:0 10px;font-size:93%;line-height:2;*line-height:1.9;font-weight:bold;color:#000;background:url(../../../../assets/skins/sam/sprite.png) repeat-x 0 -200px;}.yui-skin-sam .yui-panel .bd{padding:10px;}.yui-skin-sam .yui-panel .ft{border-top:solid 1px #808080;padding:5px 10px;font-size:77%;}.yui-skin-sam .container-close{position:absolute;top:5px;right:6px;width:25px;height:15px;background:url(../../../../assets/skins/sam/sprite.png) no-repeat 0 -300px;cursor:pointer;}.yui-skin-sam .yui-panel-container .underlay{right:-1px;left:-1px;}.yui-skin-sam .yui-panel-container.matte{padding:9px 10px;background-color:#fff;}.yui-skin-sam .yui-panel-container.shadow{_padding:2px 4px 0 2px;}.yui-skin-sam .yui-panel-container.shadow .underlay{position:absolute;top:2px;left:-3px;right:-3px;bottom:-3px;*top:4px;*left:-1px;*right:-1px;*bottom:-1px;_top:0;_left:0;_right:0;_bottom:0;_margin-top:3px;_margin-left:-1px;background-color:#000;opacity:.12;filter:alpha(opacity=12);}.yui-skin-sam .yui-dialog .ft{border-top:none;padding:0 10px 10px 10px;font-size:100%;}.yui-skin-sam .yui-dialog .ft .button-group{display:block;text-align:right;}.yui-skin-sam .yui-dialog .ft button.default{font-weight:bold;}.yui-skin-sam .yui-dialog .ft span.default{border-color:#304369;background-position:0 -1400px;}.yui-skin-sam .yui-dialog .ft span.default .first-child{border-color:#304369;}.yui-skin-sam .yui-dialog .ft span.default button{color:#fff;}.yui-skin-sam .yui-dialog .ft span.yui-button-disabled{background-position:0 -1500px;border-color:#ccc;}.yui-skin-sam .yui-dialog .ft span.yui-button-disabled .first-child{border-color:#ccc;}.yui-skin-sam .yui-dialog .ft span.yui-button-disabled button{color:#a6a6a6;}.yui-skin-sam .yui-simple-dialog .bd .yui-icon{background:url(../../../../assets/skins/sam/sprite.png) no-repeat 0 0;width:16px;height:16px;margin-right:10px;float:left;}.yui-skin-sam .yui-simple-dialog .bd span.blckicon{background-position:0 -1100px;}.yui-skin-sam .yui-simple-dialog .bd span.alrticon{background-position:0 -1050px;}.yui-skin-sam .yui-simple-dialog .bd span.hlpicon{background-position:0 -1150px;}.yui-skin-sam .yui-simple-dialog .bd span.infoicon{background-position:0 -1200px;}.yui-skin-sam .yui-simple-dialog .bd span.warnicon{background-position:0 -1900px;}.yui-skin-sam .yui-simple-dialog .bd span.tipicon{background-position:0 -1250px;}.yui-skin-sam .yui-tt .bd{position:relative;top:0;left:0;z-index:1;color:#000;padding:2px 5px;border-color:#D4C237 #A6982B #A6982B #A6982B;border-width:1px;border-style:solid;background-color:#FFEE69;}.yui-skin-sam .yui-tt.show-scrollbars .bd{overflow:auto;}.yui-skin-sam .yui-tt-shadow{top:2px;right:-3px;left:-3px;bottom:-3px;background-color:#000;}.yui-skin-sam .yui-tt-shadow-visible{opacity:.12;filter:alpha(opacity=12);}
/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
.yui-navset .yui-nav li,.yui-navset .yui-navset-top .yui-nav li,.yui-navset .yui-navset-bottom .yui-nav li{margin:0 .5em 0 0;}.yui-navset-left .yui-nav li,.yui-navset-right .yui-nav li{margin:0 0 .5em;}.yui-navset .yui-content .yui-hidden{position:absolute;left:-999999px;visibility:hidden;}.yui-navset .yui-navset-left .yui-nav,.yui-navset .yui-navset-right .yui-nav,.yui-navset-left .yui-nav,.yui-navset-right .yui-nav{width:6em;}.yui-navset-top .yui-nav,.yui-navset-bottom .yui-nav{width:auto;}.yui-navset .yui-navset-left,.yui-navset-left{padding:0 0 0 6em;}.yui-navset-right{padding:0 6em 0 0;}.yui-navset-top,.yui-navset-bottom{padding:auto;}.yui-nav,.yui-nav li{margin:0;padding:0;list-style:none;}.yui-navset li em{font-style:normal;}.yui-navset{position:relative;zoom:1;}.yui-navset .yui-content,.yui-navset .yui-content div{zoom:1;}.yui-navset .yui-content:after{content:'';display:block;clear:both;}.yui-navset .yui-nav li,.yui-navset .yui-navset-top .yui-nav li,.yui-navset .yui-navset-bottom .yui-nav li{display:inline-block;display:-moz-inline-stack;*display:inline;vertical-align:bottom;cursor:pointer;zoom:1;}.yui-navset-left .yui-nav li,.yui-navset-right .yui-nav li{display:block;}.yui-navset .yui-nav a{position:relative;}.yui-navset .yui-nav li a,.yui-navset-top .yui-nav li a,.yui-navset-bottom .yui-nav li a{display:block;display:inline-block;vertical-align:bottom;zoom:1;}.yui-navset-left .yui-nav li a,.yui-navset-right .yui-nav li a{display:block;}.yui-navset-bottom .yui-nav li a{vertical-align:text-top;}.yui-navset .yui-nav li a em,.yui-navset-top .yui-nav li a em,.yui-navset-bottom .yui-nav li a em{display:block;}.yui-navset .yui-navset-left .yui-nav,.yui-navset .yui-navset-right .yui-nav,.yui-navset-left .yui-nav,.yui-navset-right .yui-nav{position:absolute;z-index:1;}.yui-navset-top .yui-nav,.yui-navset-bottom .yui-nav{position:static;}.yui-navset .yui-navset-left .yui-nav,.yui-navset-left .yui-nav{left:0;right:auto;}.yui-navset .yui-navset-right .yui-nav,.yui-navset-right .yui-nav{right:0;left:auto;}.yui-skin-sam .yui-navset .yui-nav,.yui-skin-sam .yui-navset .yui-navset-top .yui-nav{border:solid #2647a0;border-width:0 0 5px;zoom:1;}.yui-skin-sam .yui-navset .yui-nav li,.yui-skin-sam .yui-navset .yui-navset-top .yui-nav li{margin:0 .16em 0 0;padding:1px 0 0;zoom:1;}.yui-skin-sam .yui-navset .yui-nav .selected,.yui-skin-sam .yui-navset .yui-navset-top .yui-nav .selected{margin:0 .16em -1px 0;}.yui-skin-sam .yui-navset .yui-nav a,.yui-skin-sam .yui-navset .yui-navset-top .yui-nav a{background:#d8d8d8 url(../../../../assets/skins/sam/sprite.png) repeat-x;border:solid #a3a3a3;border-width:0 1px;color:#000;position:relative;text-decoration:none;}.yui-skin-sam .yui-navset .yui-nav a em,.yui-skin-sam .yui-navset .yui-navset-top .yui-nav a em{border:solid #a3a3a3;border-width:1px 0 0;cursor:hand;padding:.25em .75em;left:0;right:0;bottom:0;top:-1px;position:relative;}.yui-skin-sam .yui-navset .yui-nav .selected a,.yui-skin-sam .yui-navset .yui-nav .selected a:focus,.yui-skin-sam .yui-navset .yui-nav .selected a:hover{background:#2647a0 url(../../../../assets/skins/sam/sprite.png) repeat-x left -1400px;color:#fff;}.yui-skin-sam .yui-navset .yui-nav a:hover,.yui-skin-sam .yui-navset .yui-nav a:focus{background:#bfdaff url(../../../../assets/skins/sam/sprite.png) repeat-x left -1300px;outline:0;}.yui-skin-sam .yui-navset .yui-nav .selected a em{padding:.35em .75em;}.yui-skin-sam .yui-navset .yui-nav .selected a,.yui-skin-sam .yui-navset .yui-nav .selected a em{border-color:#243356;}.yui-skin-sam .yui-navset .yui-content{background:#edf5ff;}.yui-skin-sam .yui-navset .yui-content,.yui-skin-sam .yui-navset .yui-navset-top .yui-content{border:1px solid #808080;border-top-color:#243356;padding:.25em .5em;}.yui-skin-sam .yui-navset-left .yui-nav,.yui-skin-sam .yui-navset .yui-navset-left .yui-nav,.yui-skin-sam .yui-navset .yui-navset-right .yui-nav,.yui-skin-sam .yui-navset-right .yui-nav{border-width:0 5px 0 0;Xposition:absolute;top:0;bottom:0;}.yui-skin-sam .yui-navset .yui-navset-right .yui-nav,.yui-skin-sam .yui-navset-right .yui-nav{border-width:0 0 0 5px;}.yui-skin-sam .yui-navset-left .yui-nav li,.yui-skin-sam .yui-navset .yui-navset-left .yui-nav li,.yui-skin-sam .yui-navset-right .yui-nav li{margin:0 0 .16em;padding:0 0 0 1px;}.yui-skin-sam .yui-navset-right .yui-nav li{padding:0 1px 0 0;}.yui-skin-sam .yui-navset-left .yui-nav .selected,.yui-skin-sam .yui-navset .yui-navset-left .yui-nav .selected{margin:0 -1px .16em 0;}.yui-skin-sam .yui-navset-right .yui-nav .selected{margin:0 0 .16em -1px;}.yui-skin-sam .yui-navset-left .yui-nav a,.yui-skin-sam .yui-navset-right .yui-nav a{border-width:1px 0;}.yui-skin-sam .yui-navset-left .yui-nav a em,.yui-skin-sam .yui-navset .yui-navset-left .yui-nav a em,.yui-skin-sam .yui-navset-right .yui-nav a em{border-width:0 0 0 1px;padding:.2em .75em;top:auto;left:-1px;}.yui-skin-sam .yui-navset-right .yui-nav a em{border-width:0 1px 0 0;left:auto;right:-1px;}.yui-skin-sam .yui-navset-left .yui-nav a,.yui-skin-sam .yui-navset-left .yui-nav .selected a,.yui-skin-sam .yui-navset-left .yui-nav a:hover,.yui-skin-sam .yui-navset-right .yui-nav a,.yui-skin-sam .yui-navset-right .yui-nav .selected a,.yui-skin-sam .yui-navset-right .yui-nav a:hover,.yui-skin-sam .yui-navset-bottom .yui-nav a,.yui-skin-sam .yui-navset-bottom .yui-nav .selected a,.yui-skin-sam .yui-navset-bottom .yui-nav a:hover{background-image:none;}.yui-skin-sam .yui-navset-left .yui-content{border:1px solid #808080;border-left-color:#243356;}.yui-skin-sam .yui-navset-bottom .yui-nav,.yui-skin-sam .yui-navset .yui-navset-bottom .yui-nav{border-width:5px 0 0;}.yui-skin-sam .yui-navset .yui-navset-bottom .yui-nav .selected,.yui-skin-sam .yui-navset-bottom .yui-nav .selected{margin:-1px .16em 0 0;}.yui-skin-sam .yui-navset .yui-navset-bottom .yui-nav li,.yui-skin-sam .yui-navset-bottom .yui-nav li{padding:0 0 1px 0;vertical-align:top;}.yui-skin-sam .yui-navset .yui-navset-bottom .yui-nav a em,.yui-skin-sam .yui-navset-bottom .yui-nav a em{border-width:0 0 1px;top:auto;bottom:-1px;}
.yui-skin-sam .yui-navset-bottom .yui-content,.yui-skin-sam .yui-navset .yui-navset-bottom .yui-content{border:1px solid #808080;border-bottom-color:#243356;}
/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
.ygtvitem{}.ygtvitem table{margin-bottom:0;border:none;}.ygtvrow td{border:none;padding:0;}.ygtvrow td a{text-decoration:none;}.ygtvtn{width:18px;height:22px;background:url(treeview-sprite.gif) 0 -5600px no-repeat;}.ygtvtm{width:18px;height:22px;cursor:pointer;background:url(treeview-sprite.gif) 0 -4000px no-repeat;}.ygtvtmh,.ygtvtmhh{width:18px;height:22px;cursor:pointer;background:url(treeview-sprite.gif) 0 -4800px no-repeat;}.ygtvtp{width:18px;height:22px;cursor:pointer;background:url(treeview-sprite.gif) 0 -6400px no-repeat;}.ygtvtph,.ygtvtphh{width:18px;height:22px;cursor:pointer;background:url(treeview-sprite.gif) 0 -7200px no-repeat;}.ygtvln{width:18px;height:22px;background:url(treeview-sprite.gif) 0 -1600px no-repeat;}.ygtvlm{width:18px;height:22px;cursor:pointer;background:url(treeview-sprite.gif) 0 0px no-repeat;}.ygtvlmh,.ygtvlmhh{width:18px;height:22px;cursor:pointer;background:url(treeview-sprite.gif) 0 -800px no-repeat;}.ygtvlp{width:18px;height:22px;cursor:pointer;background:url(treeview-sprite.gif) 0 -2400px no-repeat;}.ygtvlph,.ygtvlphh{width:18px;height:22px;cursor:pointer;background:url(treeview-sprite.gif) 0 -3200px no-repeat;}.ygtvloading{width:18px;height:22px;background:url(treeview-loading.gif) 0 0 no-repeat;}.ygtvdepthcell{width:18px;height:22px;background:url(treeview-sprite.gif) 0 -8000px no-repeat;}.ygtvblankdepthcell{width:18px;height:22px;}.ygtvchildren{}* html .ygtvchildren{height:2%;}.ygtvlabel,.ygtvlabel:link,.ygtvlabel:visited,.ygtvlabel:hover{margin-left:2px;text-decoration:none;background-color:white;cursor:pointer;}.ygtvcontent{cursor:default;}.ygtvspacer{height:22px;width:12px;}.ygtvfocus{}.ygtvfocus .ygtvlabel,.ygtvfocus .ygtvlabel:link,.ygtvfocus .ygtvlabel:visited,.ygtvfocus .ygtvlabel:hover{}.ygtvfocus a,.ygtvrow td a{outline-style:none;}.ygtvok{width:18px;height:22px;background:url(treeview-sprite.gif) 0 -8800px no-repeat;}.ygtvok:hover{background:url(treeview-sprite.gif) 0 -8844px no-repeat;}.ygtvcancel{width:18px;height:22px;background:url(treeview-sprite.gif) 0 -8822px no-repeat;}.ygtvcancel:hover{background:url(treeview-sprite.gif) 0 -8866px no-repeat;}.ygtv-label-editor{background-color:#f2f2f2;border:1px solid silver;position:absolute;display:none;overflow:hidden;margin:auto;z-index:9000;}.ygtv-edit-TextNode{width:190px;}.ygtv-edit-TextNode .ygtvcancel,.ygtv-edit-TextNode .ygtvok{border:none;}.ygtv-edit-TextNode .ygtv-button-container{float:right;}.ygtv-edit-TextNode .ygtv-input input{width:140px;}.ygtv-edit-DateNode .ygtvcancel{border:none;}.ygtv-edit-DateNode .ygtvok{display:none;}.ygtv-edit-DateNode .ygtv-button-container{text-align:right;margin:auto;}
/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
.yui-carousel{visibility:hidden;overflow:hidden;position:relative;text-align:left;zoom:1;}.yui-carousel.yui-carousel-visible{visibility:visible;}.yui-carousel-content{overflow:hidden;position:relative;}.yui-carousel-element{margin:5px 0;overflow:hidden;padding:0;position:relative;width:32000px;z-index:1;}.yui-carousel-vertical .yui-carousel-element{margin:0 5px;}.yui-carousel-element li{border:1px solid #ccc;float:left;list-style:none;margin:1px;overflow:hidden;padding:0;text-align:center;*float:none;*display:inline-block;*zoom:1;*display:inline;}.yui-carousel .yui-carousel-item-selected{border:1px dashed #000;margin:1px;}.yui-carousel-vertical{height:32000px;margin:0 5px;width:auto;}.yui-carousel-vertical .yui-carousel-element li{display:block;float:none;}.yui-log .carousel{background:#f2e886;}.yui-carousel-nav{zoom:1;}.yui-carousel-nav:after{clear:both;content:"";display:block;}.yui-carousel-button-focus{outline:1px dotted #000;}.yui-carousel-min-width .yui-carousel-content{margin:0 auto;}.yui-skin-sam .yui-carousel,.yui-skin-sam .yui-carousel-vertical{border:1px solid #808080;}.yui-skin-sam .yui-carousel-nav{background:url(../pacotes/yui270/build/assets/skins/sam/sprite.png) repeat-x 0 0;padding:3px;text-align:right;}.yui-skin-sam .yui-carousel-button{background:url(../pacotes/yui270/build/assets/skins/sam/sprite.png) no-repeat 0 -600px;float:right;height:19px;margin:5px;overflow:hidden;width:40px;}.yui-skin-sam .yui-carousel-vertical .yui-carousel-button{background-position:0 -800px;}.yui-skin-sam .yui-carousel-button-disabled{background-position:0 -2000px;}.yui-skin-sam .yui-carousel-vertical .yui-carousel-button-disabled{background-position:0 -2100px;}.yui-skin-sam .yui-carousel-button input,.yui-skin-sam .yui-carousel-button button{background-color:transparent;border:0;cursor:pointer;display:block;height:44px;margin:-2px 0 0 -2px;padding:0 0 0 50px;}.yui-skin-sam span.yui-carousel-first-button{background-position:0 -550px;margin-left:-100px;margin-right:50px;*margin:5px 5px 5px -90px;}.yui-skin-sam .yui-carousel-vertical span.yui-carousel-first-button{background-position:0 -750px;}.yui-skin-sam span.yui-carousel-first-button-disabled{background-position:0 -1950px;}.yui-skin-sam .yui-carousel-vertical span.yui-carousel-first-button-disabled{background-position:0 -2050px;}.yui-skin-sam .yui-carousel-nav ul{float:right;height:19px;margin:0;margin-left:-220px;margin-right:100px;*margin-left:-160px;*margin-right:0;padding:0;}.yui-skin-sam .yui-carousel-min-width .yui-carousel-nav ul{*margin-left:-170px;}.yui-skin-sam .yui-carousel-nav select{position:relative;*right:50px;top:4px;}.yui-skin-sam .yui-carousel-vertical .yui-carousel-nav ul,.yui-skin-sam .yui-carousel-vertical .yui-carousel-nav select{float:none;margin:0;*zoom:1;}.yui-skin-sam .yui-carousel-nav ul li{background:url(../pacotes/yui270/build/assets/skins/sam/sprite.png) no-repeat 0 -650px;cursor:pointer;float:left;height:9px;list-style:none;margin:10px 0 0 5px;overflow:hidden;padding:0;width:9px;}.yui-skin-sam .yui-carousel-nav ul:after{clear:both;content:"";display:block;}.yui-skin-sam .yui-carousel-nav ul li a{left:-10000px;position:absolute;}.yui-skin-sam .yui-carousel-nav ul li.yui-carousel-nav-page-focus{outline:1px dotted #000;}.yui-skin-sam .yui-carousel-nav ul li.yui-carousel-nav-page-selected{background-position:0 -700px;}.yui-skin-sam .yui-carousel-item-loading{background:url(ajax-loader.gif) no-repeat 50% 50%;position:relative;text-indent:-150px;}
/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
.yui-h-slider,
.yui-v-slider{position:relative;}
.yui-h-slider .yui-slider-thumb,
.yui-v-slider .yui-slider-thumb{position:absolute;cursor:default;}
.yui-skin-sam .yui-h-slider .yui-slider-thumb{top:4px;}
/*
Copyright (c) 2009, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.7.0
*/
.yui-resize{position:relative;zoom:1;z-index:0;}.yui-resize-wrap{zoom:1;}.yui-draggable{cursor:move;}.yui-resize .yui-resize-handle{position:absolute;z-index:1;font-size:0;margin:0;padding:0;zoom:1;height:1px;width:1px;}.yui-resize .yui-resize-handle-br{height:5px;width:5px;bottom:0;right:0;cursor:se-resize;z-index:2;zoom:1;}.yui-resize .yui-resize-handle-bl{height:5px;width:5px;bottom:0;left:0;cursor:sw-resize;z-index:2;zoom:1;}.yui-resize .yui-resize-handle-tl{height:5px;width:5px;top:0;left:0;cursor:nw-resize;z-index:2;zoom:1;}.yui-resize .yui-resize-handle-tr{height:5px;width:5px;top:0;right:0;cursor:ne-resize;z-index:2;zoom:1;}.yui-resize .yui-resize-handle-r{width:5px;height:100%;top:0;right:0;cursor:e-resize;zoom:1;}.yui-resize .yui-resize-handle-l{height:100%;width:5px;top:0;left:0;cursor:w-resize;zoom:1;}.yui-resize .yui-resize-handle-b{width:100%;height:5px;bottom:0;right:0;cursor:s-resize;zoom:1;}.yui-resize .yui-resize-handle-t{width:100%;height:5px;top:0;right:0;cursor:n-resize;zoom:1;}.yui-resize-proxy{position:absolute;border:1px dashed #000;visibility:hidden;z-index:1000;}.yui-resize-hover .yui-resize-handle,.yui-resize-hidden .yui-resize-handle{opacity:0;filter:alpha(opacity=0);}.yui-resize-ghost{opacity:.5;filter:alpha(opacity=50);}.yui-resize-knob .yui-resize-handle{height:6px;width:6px;}.yui-resize-knob .yui-resize-handle-tr{right:-3px;top:-3px;}.yui-resize-knob .yui-resize-handle-tl{left:-3px;top:-3px;}.yui-resize-knob .yui-resize-handle-bl{left:-3px;bottom:-3px;}.yui-resize-knob .yui-resize-handle-br{right:-3px;bottom:-3px;}.yui-resize-knob .yui-resize-handle-t{left:45%;top:-3px;}.yui-resize-knob .yui-resize-handle-r{right:-3px;top:45%;}.yui-resize-knob .yui-resize-handle-l{left:-3px;top:45%;}.yui-resize-knob .yui-resize-handle-b{left:45%;bottom:-3px;}.yui-resize-status{position:absolute;top:-999px;left:-999px;padding:2px;font-size:80%;display:none;zoom:1;z-index:9999;}.yui-resize-status strong,.yui-resize-status em{font-weight:normal;font-style:normal;padding:1px;zoom:1;}.yui-skin-sam .yui-resize .yui-resize-handle{background-color:#F2F2F2;zoom:1;}.yui-skin-sam .yui-resize .yui-resize-handle-active{background-color:#7D98B8;zoom:1;}.yui-skin-sam .yui-resize .yui-resize-handle-l,.yui-skin-sam .yui-resize .yui-resize-handle-r,.yui-skin-sam .yui-resize .yui-resize-handle-l-active,.yui-skin-sam .yui-resize .yui-resize-handle-r-active{height:100%;zoom:1;}.yui-skin-sam .yui-resize-knob .yui-resize-handle{border:1px solid #808080;}.yui-skin-sam .yui-resize-hover .yui-resize-handle-active{opacity:1;filter:alpha(opacity=100);}.yui-skin-sam .yui-resize-proxy{border:1px dashed #426FD9;}.yui-skin-sam .yui-resize-status{border:1px solid #A6982B;border-top:1px solid #D4C237;background-color:#FFEE69;color:#000;}.yui-skin-sam .yui-resize-status strong,.yui-skin-sam .yui-resize-status em{float:left;display:block;clear:both;padding:1px;text-align:center;}.yui-skin-sam .yui-resize .yui-resize-handle-inner-r,.yui-skin-sam .yui-resize .yui-resize-handle-inner-l{background:transparent url(layout_sprite.png) no-repeat 0 -5px;height:16px;width:5px;position:absolute;top:45%;}.yui-skin-sam .yui-resize .yui-resize-handle-inner-t,.yui-skin-sam .yui-resize .yui-resize-handle-inner-b{background:transparent url(layout_sprite.png) no-repeat -20px 0;height:5px;width:16px;position:absolute;left:50%;}.yui-skin-sam .yui-resize .yui-resize-handle-br{background-image:url(layout_sprite.png);background-repeat:no-repeat;background-position:-22px -62px;}.yui-skin-sam .yui-resize .yui-resize-handle-tr{background-image:url(layout_sprite.png);background-repeat:no-repeat;background-position:-22px -42px;}.yui-skin-sam .yui-resize .yui-resize-handle-tl{background-image:url(layout_sprite.png);background-repeat:no-repeat;background-position:-22px -82px;}.yui-skin-sam .yui-resize .yui-resize-handle-bl{background-image:url(layout_sprite.png);background-repeat:no-repeat;background-position:-22px -23px;}.yui-skin-sam .yui-resize-knob .yui-resize-handle-t,.yui-skin-sam .yui-resize-knob .yui-resize-handle-r,.yui-skin-sam .yui-resize-knob .yui-resize-handle-b,.yui-skin-sam .yui-resize-knob .yui-resize-handle-l,.yui-skin-sam .yui-resize-knob .yui-resize-handle-tl,.yui-skin-sam .yui-resize-knob .yui-resize-handle-tr,.yui-skin-sam .yui-resize-knob .yui-resize-handle-bl,.yui-skin-sam .yui-resize-knob .yui-resize-handle-br,.yui-skin-sam .yui-resize-knob .yui-resize-handle-inner-t,.yui-skin-sam .yui-resize-knob .yui-resize-handle-inner-r,.yui-skin-sam .yui-resize-knob .yui-resize-handle-inner-b,.yui-skin-sam .yui-resize-knob .yui-resize-handle-inner-l,.yui-skin-sam .yui-resize-knob .yui-resize-handle-inner-tl,.yui-skin-sam .yui-resize-knob .yui-resize-handle-inner-tr,.yui-skin-sam .yui-resize-knob .yui-resize-handle-inner-bl,.yui-skin-sam .yui-resize-knob .yui-resize-handle-inner-br{background-image:none;}.yui-skin-sam .yui-resize-knob .yui-resize-handle-l,.yui-skin-sam .yui-resize-knob .yui-resize-handle-r,.yui-skin-sam .yui-resize-knob .yui-resize-handle-l-active,.yui-skin-sam .yui-resize-knob .yui-resize-handle-r-active{height:6px;width:6px;}.yui-skin-sam .yui-resize-textarea .yui-resize-handle-r{right:-8px;}.yui-skin-sam .yui-resize-textarea .yui-resize-handle-b{bottom:-8px;}.yui-skin-sam .yui-resize-textarea .yui-resize-handle-br{right:-8px;bottom:-8px;}
/*
Copyright (c) 2011, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.com/yui/license.html
version: 2.9.0
*/
.yui-pb-bar,.yui-pb-mask{width:100%;height:100%}.yui-pb{position:relative;top:0;left:0;width:200px;height:20px;padding:0;border:0;margin:0;text-align:left}.yui-pb-mask{position:absolute;top:0;left:0;z-index:2}.yui-pb-mask div{width:50%;height:50%;background-repeat:no-repeat;padding:0;position:absolute}.yui-pb-tl{background-position:top left}.yui-pb-tr{background-position:top right;left:50%}.yui-pb-bl{background-position:bottom left;top:50%}.yui-pb-br{background-position:bottom right;left:50%;top:50%}.yui-pb-bar{margin:0;position:absolute;left:0;top:0;z-index:1}.yui-pb-ltr .yui-pb-bar{_position:static}.yui-pb-rtl .yui-pb-bar{background-position:right}.yui-pb-btt .yui-pb-bar{background-position:left bottom}.yui-pb-bar{background-color:blue}.yui-pb{border:thin solid #808080}.yui-skin-sam .yui-pb{background-color:transparent;border:solid #808080;border-width:1px 0}.yui-skin-sam .yui-pb-rtl,.yui-skin-sam .yui-pb-ltr{background-image:url(back-h.png);background-repeat:repeat-x}.yui-skin-sam .yui-pb-ttb,.yui-skin-sam .yui-pb-btt{background-image:url(back-v.png);background-repeat:repeat-y}.yui-skin-sam .yui-pb-bar{background-color:transparent}.yui-skin-sam .yui-pb-ltr .yui-pb-bar,.yui-skin-sam .yui-pb-rtl .yui-pb-bar{background-image:url(bar-h.png);background-repeat:repeat-x}.yui-skin-sam .yui-pb-ttb .yui-pb-bar,.yui-skin-sam .yui-pb-btt .yui-pb-bar{background-image:url(bar-v.png);background-repeat:repeat-y}.yui-skin-sam .yui-pb-mask{border:solid #808080;border-width:0 1px;margin:0 -1px}.yui-skin-sam .yui-pb-caption{color:#000;text-align:center;margin:0 auto}.yui-skin-sam .yui-pb-range{color:#a6a6a6}
.yui-skin-sam .yuimenubar {
background:transparent url(../pacotes/yui270/build/assets/skins/sam/sprite.png) repeat-x scroll 0 0;
border:1px solid #808080;
font-size:93%;
line-height:2;
}
.yui-skin-sam .yuimenubarnav .yuimenubaritemlabel-hassubmenu {
background:transparent url(../pacotes/yui270/build/menu/assets/skins/sam/menubaritem_submenuindicator.png) no-repeat scroll right center;
}
.yui-skin-sam .yuimenubaritem-selected {
background:transparent url(../pacotes/yui270/build/assets/skins/sam/sprite.png) repeat-x scroll 0 -1700px;
}
.yui-skin-sam .yuimenubarnav .yuimenubaritemlabel-hassubmenu-disabled {
background-image:url(../pacotes/yui270/build/menu/assets/skins/sam/menubaritem_submenuindicator_disabled.png);
}

.yuimenubaritem {
float:right;
border-left: 1px solid gray;
}

.yui-skin-sam .yuimenubaritemlabel
{
border-color:#808080;
border-style:solid;
border-width:1px 0;
color:#000000;
cursor:default;
margin:-1px 0;
padding:0 20px;
text-decoration:none;
}

.yui-skin-sam .topscrollbar, .yui-skin-sam .bottomscrollbar {
background:#FFFFFF url(../pacotes/yui270/build/assets/skins/sam/sprite.png) no-repeat scroll 0 0;
border:1px solid #808080;
height:16px;
}

.yui-skin-sam .yuimenuitem-hassubmenu {
background-image:url(../pacotes/yui270/build/menu/assets/skins/sam/menuitem_submenuindicator.png);
background-position:right center;
background-repeat:no-repeat;
}

.yui-skin-sam .yuimenuitem-checked {
background-image:url(../pacotes/yui270/build/menu/assets/skins/sam/menuitem_checkbox.png);
background-position:left center;
background-repeat:no-repeat;
}

.yui-skin-sam .yuimenuitem-hassubmenu-disabled {
background-image:url(../pacotes/yui270/build/menu/assets/skins/sam/menuitem_submenuindicator_disabled.png);
}

.yui-skin-sam .yuimenuitem-checked-disabled {
background-image:url(../pacotes/yui270/build/menu/assets/skins/sam/menuitem_checkbox_disabled.png);
}

.yui-skin-sam .yui-panel .hd {
background:transparent url(../pacotes/yui270/build/assets/skins/sam/sprite.png) repeat-x scroll 0 -200px;
color:#000000;
font-size:80%;
font-weight:bold;
line-height:2;
padding:0 10px;
height:20px;
}

.yui-skin-sam .yui-panel .hd2 {
background:transparent url(../pacotes/yui270/build/assets/skins/sam/sprite.png) repeat-x scroll 0 -200px;
color:#000000;
font-size:80%;
font-weight:bold;
line-height:2;
padding:0 10px;
height:20px;
opacity:.80;
filter:alpha(opacity=80);
}

.yui-skin-sam .container-close {
background:transparent url(../pacotes/yui270/build/assets/skins/sam/sprite.png) no-repeat scroll 0 -300px;
cursor:pointer;
height:15px;
position:absolute;
right:1px;
top:1px;
width:25px;
z-index:2001;
opacity:.80;
filter:alpha(opacity=80);
}

.yui-skin-sam .container-minimiza {
background:transparent url(../pacotes/yui270/build/assets/skins/sam/sprite.png) no-repeat scroll 0 -450px;
cursor:pointer;
height:15px;
position:absolute;
right:30px;
top:1px;
width:25px;
z-index:2001;
opacity:.8;
filter:alpha(opacity=80);
}

.yui-skin-sam .yui-panel .bd{
	text-align: left;
	font-size: 10px;
}

.yui-skin-sam .yui-simple-dialog .bd .yui-icon {
background:transparent url(../pacotes/yui270/build/assets/skins/sam/sprite.png) no-repeat scroll 0 0;
float:left;
height:16px;
margin-right:10px;
width:16px;
}

.yui-navset{
    background:#d8d8d8 url(../pacotes/yui270/build/assets/skins/sam/sprite.png) repeat-x; /* tab background */
	z-index:3000;
}

.ygtvtn
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 -5600px;
	height:22px;
	width:18px;
}
.ygtvln
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 -1600px;
	height:22px;
	width:18px;
}
.ygtvtp
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 -6400px;
	cursor:pointer;
	height:22px;
	width:18px;
}
.ygtvtph
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 -7200px;
	cursor:pointer;
	height:22px;
	width:18px;
}

.ygtvlp
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 -2400px;
	cursor:pointer;
	height:22px;
	width:18px;
}
.ygtvlph
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 -3200px;
	cursor:pointer;
	height:22px;
	width:18px;
}

.ygtvloading
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-loading.gif) no-repeat scroll 0 0;
	height:22px;
	width:18px;
}
.ygtvlm
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 0;
	cursor:pointer;
	height:22px;
	width:18px;
}
.ygtvlmh
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 -800px;
	cursor:pointer;
	height:22px;
	width:18px;
}
.ygtvdepthcell 
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 -8000px;
	height:22px;
	width:18px;
}
.ygtvtm
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 -4000px;
	cursor:pointer;
	height:22px;
	width:18px;
}
.ygtvtmh
{
	background:transparent url(../pacotes/yui270/build/assets/skins/sam/treeview-sprite.gif) no-repeat scroll 0 -4800px;
	cursor:pointer;
	height:22px;
	width:18px;
}
.ygtvhtml{text-align:left;}
.ygtvitem{text-align:left;}

.yui-skin-sam .yui-navset .yui-nav a,.yui-skin-sam .yui-navset .yui-navset-top .yui-nav a
{background:#d8d8d8 url(../pacotes/yui270/build/assets/skins/sam/sprite.png) repeat-x;border:solid #a3a3a3;border-width:0 1px;color:#000;position:relative;text-decoration:none;}
.yui-skin-sam .yui-navset .yui-nav .selected a,.yui-skin-sam .yui-navset .yui-nav .selected a:focus,.yui-skin-sam .yui-navset .yui-nav .selected a:hover
{background:white url(../pacotes/yui270/build/assets/skins/sam/sprite.png) repeat-x left -1400px;color:white;}
.yui-skin-sam .yui-navset .yui-nav a:hover,.yui-skin-sam .yui-navset .yui-nav a:focus{
	background-color:white;
}

.yui-skin-sam .yui-button button, .yui-skin-sam .yui-button a {
	color:#000000;
	font-size:95%;
	line-height:2;
	min-height:1em;
	padding:0 10px;
}
.yui-resize .yui-resize-handle{position:absolute;z-index:1;font-size:0;margin:0;padding:0;zoom:1;height:250px;width:5px;}
.olControlEditingToolbar1 .editorOLpanItemInactive {
background-position:-0px 0;
}
.olControlEditingToolbar1 .editorOLpanItemActive {
background-position:-0px -28px;
}
.olControlEditingToolbar1 .editorOLzoomboxItemInactive {
background-position:-29px 0;
}
.olControlEditingToolbar1 .editorOLzoomboxItemActive {
background-position:-29px -28px;
}
.olControlEditingToolbar1 .editorOLzoomtotItemInactive {
background-position:-58px 0;
}
.olControlEditingToolbar1 .editorOLzoomtotItemActive {
background-position:-58px -28px;
}
.olControlEditingToolbar1 .editorOLlegendaItemInactive {
background-position:-87px 0;
}
.olControlEditingToolbar1 .editorOLlegendaItemActive {
background-position:-87px -28px;
}
.olControlEditingToolbar1 .editorOLdistanciaItemInactive {
background-position:-116px 0;
}
.olControlEditingToolbar1 .editorOLdistanciaItemActive {
background-position:-116px -28px;
}
.olControlEditingToolbar1 .editorOLareaItemInactive {
background-position:-145px 0;
}
.olControlEditingToolbar1 .editorOLareaItemActive {
background-position:-145px -28px;
}
.olControlEditingToolbar1 .editorOLidentificaItemInactive {
background-position:-174px 0;
}
.olControlEditingToolbar1 .editorOLidentificaItemActive {
background-position:-174px -28px;
}
.olControlEditingToolbar1 .editorOLlinhaItemInactive {
background-position:-203px 0;
}
.olControlEditingToolbar1 .editorOLlinhaItemActive {
background-position:-203px -28px;
}
.olControlEditingToolbar1 .editorOLpontoItemInactive {
background-position:-232px 0;
}
.olControlEditingToolbar1 .editorOLpontoItemActive {
background-position:-232px -28px;
}
.olControlEditingToolbar1 .editorOLpoligonoItemInactive {
background-position:-261px 0;
}
.olControlEditingToolbar1 .editorOLpoligonoItemActive {
background-position:-261px -28px;
}
.olControlEditingToolbar1 .editorOLeditaItemInactive {
background-position:-290px 0;
}
.olControlEditingToolbar1 .editorOLeditaItemActive {
background-position:-290px -28px;
}
.olControlEditingToolbar1 .editorOLapagaItemInactive {
background-position:-319px 0;
}
.olControlEditingToolbar1 .editorOLapagaItemActive {
background-position:-319px -28px;
}
.olControlEditingToolbar1 .editorOLselecaoItemInactive {
background-position:-348px 0;
}
.olControlEditingToolbar1 .editorOLselecaoItemActive {
background-position:-348px -28px;
}
.olControlEditingToolbar1 .editorOLcapturaItemInactive {
background-position:-377px 0;
}
.olControlEditingToolbar1 .editorOLcapturaItemActive {
background-position:-377px -28px;
}
.olControlEditingToolbar1 .editorOLprocuraItemInactive {
background-position:-406px 0;
}
.olControlEditingToolbar1 .editorOLprocuraItemActive {
background-position:-406px -28px;
}
.olControlEditingToolbar1 .editorOLsalvaItemInactive {
background-position:-435px 0;
}
.olControlEditingToolbar1 .editorOLsalvaItemActive {
background-position:-435px -28px;
}
.olControlEditingToolbar1 .editorOLfechaItemInactive {
background-position:-464px 0;
}
.olControlEditingToolbar1 .editorOLfechaItemActive {
background-position:-464px -28px;
}
.olControlEditingToolbar1 .editorOLajudaItemInactive {
background-position:-493px 0;
}
.olControlEditingToolbar1 .editorOLajudaItemActive {
background-position:-493px -28px;
}
.olControlEditingToolbar1 .editorOLpropriedadesItemInactive {
background-position:-522px 0;
}
.olControlEditingToolbar1 .editorOLpropriedadesItemActive {
background-position:-522px -28px;
}
.olControlEditingToolbar1 .editorOLuniaoItemInactive {
	background-position:-551px 0;
}
.olControlEditingToolbar1 .editorOLuniaoItemActive {
	background-position:-551px -28px;
}
.olControlEditingToolbar1 .editorOLtoolsItemInactive {
	background-position:-580px 0;
}
.olControlEditingToolbar1 .editorOLtoolsItemActive {
	background-position:-580px -28px;
}
.olControlEditingToolbar1 .editorOLundoItemInactive {
	background-position:-609px 0;
}
.olControlEditingToolbar1 .editorOLundoItemActive {
	background-position:-609px -28px;
}
.olControlEditingToolbar1 .editorOLfrenteItemInactive {
	background-position:-638px 0;
}
.olControlEditingToolbar1 .editorOLfrenteItemActive {
	background-position:-638px -28px;
}
.olControlEditingToolbar1 .editorOLtextoItemInactive {
	background-position:-667px 0;
}
.olControlEditingToolbar1 .editorOLtextoItemActive {
	background-position:-667px -28px;
}
.olControlEditingToolbar1 .editorOLcortaItemInactive {
	background-position:-696px 0;
}
.olControlEditingToolbar1 .editorOLcortaItemActive {
	background-position:-696px -28px;
}
.olControlEditingToolbar1 .editorOLlistagItemInactive {
	background-position:-725px 0;
}
.olControlEditingToolbar1 .editorOLlistagItemActive {
	background-position:-725px -28px;
}
.olControlEditingToolbar1 {
	width:650px;
	float:right;
	right: 0px;
}
.olControlEditingToolbar1 div {
	background-image:url(openlayers.png);
	background-repeat:no-repeat;
	float:right;
	right: 0px;	
	height:29px;
	margin:2px;
	width:29px;
}

@media print {
	.olControlPanZoomBar {display:none !important;}
	.maximizeDiv {display:none !important;}
	.olControlOverviewMapMaximizeButton {display:none !important;}
}

pre{
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;	
}
.yui-skin-sam .container-close {
background:transparent url(../pacotes/yui270/build/assets/skins/sam/sprite.png) no-repeat scroll 0 -300px;
cursor:pointer;
height:15px;
position:absolute;
right:1px;
top:1px;
width:25px;
z-index:2001;
opacity:.80;
filter:alpha(opacity=80);
}
<?php if(extension_loaded('zlib')){ob_end_flush();}?>